# Astra Ultra review — Veeam ONE → Alerta script integration

24 September 2026 · Revision 2

An independent **GPT-6 Astra reviewer at Ultra reasoning effort** reviewed the original scripts, configuration, runbook and ZIP, checked official documentation and Alerta v9.1.0 source, and reviewed the revised code. The review found **three high-severity defects** in the first package. Those defects have been corrected in revision 2. No additional PowerShell 5.1 syntax or binding blocker was identified in the second static pass.

This is a reviewed starter, not a production acceptance signoff. The preparation environment has no Windows PowerShell 5.1, Veeam notification service, task-account DPAPI context, or live Alerta/Patroni deployment. No live system was changed.

## Findings and disposition

| Severity | Finding in first package | Revision 2 disposition |
|---|---|---|
| **High** | Sequence-file replacement supplied ordinary PowerShell `$null` to a .NET string parameter. Conversion to an empty backup pathname can fail on the second capture, before its event is published. | Corrected using `System.Management.Automation.Language.NullString.Value`. A new native Windows test covers three consecutive captures. Source-supported static finding; not reproduced on Windows here. |
| **High** | Active alarms inherited Alerta's one-day expiry. A persistent Veeam Error might receive no further transition and expire without resolving. | Error/Warning explicitly send `timeout=0`; Resolved uses `resolvedTimeoutSeconds`, default 86400. Missed clear events now require reconciliation instead of silent expiry. Already stored alerts need separate current-state review. |
| **High** | A single blackout response held the global queue head and blocked every later alarm, including unrelated resources. | A validated blackout 202 is archived in `suppressed` with diagnostics, then the worker continues. It is an intentional suppression outcome, not successful alert storage. Post-maintenance reconciliation remains required. |
| Medium | Missing top-level `createTime` made each replay appear newly generated and changed blackout matching. | A validated immutable capture timestamp is sent as UTC milliseconds. This is local capture time, not a guaranteed Veeam transition time. Implemented together with terminal 202 handling. |
| Medium | Instructions suggested manually requeuing failed historical events. An old Error could reopen an alert after a newer Resolved had already been delivered. | Runbook now prohibits blind replay. Inspect current Veeam state and subsequent captures, then emit a fresh reconciled observation when justified. No automatic safe requeue tool is included. |
| Medium | HTTP 400/422 discarded the receiver's rejection explanation. | Protected diagnostic sidecars retain processing time, status, bounded response excerpt, capture SHA-256 and delivery configuration context. The known API key is redacted; request headers are never saved. Local malformed-record errors also have diagnostics. |
| Low | The firewall table combined etcd client and peer ports. | Split Patroni → etcd TCP 2379 from etcd member → member TCP 2380. Veeam still needs only the application HTTPS path. |

## Additional changes

- Retry metadata now uses a flushed temporary file and atomic replacement. Missing or corrupt retry metadata remains visible and recoverable without losing the original queued record.
- Capture rejects a missing sequence counter when existing ready or archived records are present. The counter must survive reinstalls and archive cleanup.
- Configuration rejects absent, empty or non-string service values. Endpoint validation rejects embedded credentials, query strings and fragments.
- Queue health includes oldest temporary-file age and the time suppression was processed.
- The worker has a configurable soft run budget, default 240 seconds, ahead of the recommended five-minute Task Scheduler hard limit. It does not guarantee cancellation of every slow in-flight operation.
- Script/configuration write permissions are reserved for deployment administrators. Runtime-account ACL and DPAPI checks remain installation requirements.
- Capture no longer attempts logging to a default production queue before its own configuration is loaded.
- Upgrade handling compares SHA-256 before removing a ready original that already has an identical old blackout audit copy.

## Remaining findings and limits

**Medium — delayed events can interact with later operator acknowledgments.** The reviewer exercised Alerta v9.1.0's state-machine code in a Python probe with dependency stubs. A delayed Error can reopen an acknowledged Warning, while a retry of that Error can restore the later acknowledgment because history is ordered by event time. This probe supports the source-level finding; it is not a live Alerta test. Revision 2 documents and adds an acceptance scenario for this interaction. It does not implement server-side idempotency, a delivery watermark, or a replacement Alerta state machine.

**Current-state reconciliation is still missing.** The Veeam action covers documented Error, Warning and Resolved transitions. It cannot repair a capture failure, recover a missed clear, refresh a persistent maintenance-suppressed error, or guarantee per-child-job identity where `%7` groups child alarms. The recommended starter operation avoids blackouts matching this feed until a reconciliation process exists. Notification blackout mode stores alerts, but does not by itself return a persistent alarm from blackout status when maintenance ends.

**The queue is ordered by local capture invocation, with at-least-once delivery after successful spooling.** Temporary API errors still stop the global queue to preserve this order. Veeam supplies no source sequence here. A crash after accepted POST and before local archive may duplicate a send. Freeze identity/routing configuration during a backlog; payloads use the current configuration at delivery time.

**HA does not prove end-to-end durability.** The sender requires no direct access or changes to PostgreSQL, Patroni, etcd or PgBouncer. Live API routing, primary-only writer selection, PgBouncer recovery and etcd quorum remain deployment acceptance checks. This package neither provisions nor validates those services.

## Validation performed and next checks

Completed: original archive integrity and source equality; official-documentation and upstream-source review; independent second static review of corrected scripts and regression harness; configuration and targeted static assertions; revised ZIP integrity and manifest verification during packaging.

Added `Test-LocalQueue.ps1`, to run on an isolated Windows PowerShell 5.1 machine. It checks native parsing, three captures and sequence replacement, rejection paths, stable identity/time, active/resolved timeout mapping and DryRun isolation. **This harness has not been executed here.** It does not test HTTPS or DPAPI.

Before deployment, run the harness and verify actual service-account capture, concurrent capture, scheduled-account decryption, Error → Warning → Resolved, an unchanged Error beyond one day, blackout isolation, 400 diagnostics, accepted-POST interruption, the delayed Error/ACK/retry scenario, and application/database failover. The README contains installation, upgrade and recovery details.

## Evidence

- [Microsoft PowerShell NullString](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.language.nullstring?view=powershellsdk-7.6.0) and [File.Replace](https://learn.microsoft.com/en-us/dotnet/api/system.io.file.replace?view=netframework-4.8.1).
- [Alerta configuration](https://docs.alerta.io/configuration.html), [API fields](https://docs.alerta.io/api/reference.html), [v9.1.0 PostgreSQL implementation](https://github.com/alerta/alerta/blob/v9.1.0/alerta/database/backends/postgres/base.py), [alert model](https://github.com/alerta/alerta/blob/v9.1.0/alerta/models/alert.py) and [blackout plugin](https://github.com/alerta/alerta/blob/v9.1.0/alerta/plugins/blackout.py).
- [Veeam ONE notification documentation](https://helpcenter.veeam.com/docs/one/userguide/alarm_notifications.html).

Original reviewed ZIP SHA-256: `448ce428c512e4c11cbd673ef34129b3d1691a557b2e774d27b8a374594bc3d7`. The revised package has a regenerated `SHA256SUMS.txt`; do not use the original digest to validate revision 2.
