# Windows PowerShell 5.1. Notification action arguments: "%7" "%5" "%6".
[CmdletBinding()]
param(
    [Parameter(Position = 0, Mandatory = $true)][string]$AlarmKey,
    [Parameter(Position = 1, Mandatory = $true)][string]$State,
    [Parameter(Position = 2)][AllowEmptyString()][string]$PreviousState = ''
)

$ErrorActionPreference = 'Stop'
$root = $null
$utf8 = [System.Text.UTF8Encoding]::new($false)
$mutex = [System.Threading.Mutex]::new($false, 'Global\VeeamOneAlertaCapture')
$lockTaken = $false
try {
    $config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $root = [string]$config.queueRoot
    if ([string]::IsNullOrWhiteSpace($root)) { throw 'queueRoot must be configured.' }
    if ([string]::IsNullOrWhiteSpace($AlarmKey) -or $AlarmKey.Length -gt 512) {
        throw 'Veeam ONE %7 must be present and no longer than 512 characters.'
    }
    if ($State -cnotin @('Error', 'Warning', 'Resolved')) {
        throw ('Unsupported Veeam ONE notification state: ' + $State)
    }
    $ready = Join-Path $root 'ready'
    if (-not (Test-Path -LiteralPath $ready -PathType Container)) {
        throw ('The local ready queue does not exist: ' + $ready)
    }

    try { $lockTaken = $mutex.WaitOne(30000) }
    catch [System.Threading.AbandonedMutexException] { $lockTaken = $true }
    if (-not $lockTaken) { throw 'Could not acquire the capture-sequence lock within 30 seconds.' }

    # One monotonically increasing local sequence across all capture processes on this host.
    # Persist it BEFORE publishing the record. A crash may leave a harmless gap.
    $sequenceFile = Join-Path $root 'capture-sequence.txt'
    $last = [long]0
    if (Test-Path -LiteralPath $sequenceFile) {
        $last = [long]::Parse((Get-Content -LiteralPath $sequenceFile -Raw).Trim())
        if ($last -lt 0) { throw 'Capture sequence must not be negative.' }
    } else {
        foreach ($folder in @('ready', 'sent', 'suppressed', 'dead')) {
            $directory = Join-Path $root $folder
            if (Test-Path -LiteralPath $directory -PathType Container) {
                $existing = Get-ChildItem -LiteralPath $directory -Filter '*.ready' -File | Select-Object -First 1
                if ($null -ne $existing) { throw 'Capture sequence is missing while queue records exist. Restore it before capturing.' }
            }
        }
    }
    if ($last -eq [long]::MaxValue) { throw 'Capture sequence is exhausted.' }
    $next = [long]($last + 1)
    $sequenceTemporary = Join-Path $root ('capture-sequence-{0}.tmp' -f [Guid]::NewGuid().ToString('N'))
    $sequenceBytes = $utf8.GetBytes([string]$next)
    $sequenceStream = [System.IO.FileStream]::new(
        $sequenceTemporary,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None
    )
    try {
        $sequenceStream.Write($sequenceBytes, 0, $sequenceBytes.Length)
        $sequenceStream.Flush($true)
    } finally { $sequenceStream.Dispose() }
    if (Test-Path -LiteralPath $sequenceFile) {
        [System.IO.File]::Replace($sequenceTemporary, $sequenceFile, [System.Management.Automation.Language.NullString]::Value)
    } else {
        [System.IO.File]::Move($sequenceTemporary, $sequenceFile)
    }

    $now = [DateTime]::UtcNow
    $record = [ordered]@{
        schemaVersion = 1
        captureId = [Guid]::NewGuid().ToString('D')
        captureSequence = $next
        capturedAtUtc = $now.ToString('o')
        alarmKey = $AlarmKey
        state = $State
        previousState = $PreviousState
    }
    $bytes = $utf8.GetBytes(($record | ConvertTo-Json -Depth 5 -Compress))
    $baseName = '{0:D20}-{1}' -f $next, $record.captureId
    $temporary = Join-Path $ready ($baseName + '.tmp')
    $published = Join-Path $ready ($baseName + '.ready')
    $stream = [System.IO.FileStream]::new(
        $temporary,
        [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write,
        [System.IO.FileShare]::None
    )
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally { $stream.Dispose() }
    [System.IO.File]::Move($temporary, $published)
} catch {
    # Best effort only: disk-full or ACL failures can prevent local logging too.
    try {
        $line = '[{0}] {1}{2}' -f [DateTime]::UtcNow.ToString('o'), $_.Exception.Message, [Environment]::NewLine
        if (-not [string]::IsNullOrWhiteSpace($root)) {
            [System.IO.File]::AppendAllText((Join-Path $root 'capture-failures.log'), $line, $utf8)
        }
    } catch {}
    throw
} finally {
    if ($lockTaken) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
