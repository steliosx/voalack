# Windows PowerShell 5.1. Run once per scheduled invocation under the dedicated worker identity.
[CmdletBinding()]
param([switch]$DryRun)

$ErrorActionPreference = 'Stop'
$config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$root = [string]$config.queueRoot
$readyDir = Join-Path $root 'ready'
$apiUri = [Uri]([string]$config.apiUrl)
if ($apiUri.Scheme -ne 'https' -or $apiUri.AbsolutePath -notlike '*/api/alert' -or
    $apiUri.UserInfo -ne '' -or $apiUri.Query -ne '' -or $apiUri.Fragment -ne '') {
    throw 'apiUrl must be an HTTPS URL ending in /api/alert.'
}
if ([string]::IsNullOrWhiteSpace([string]$config.instance) -or
    [string]::IsNullOrWhiteSpace([string]$config.environment) -or
    @($config.service).Count -eq 0 -or $null -eq $config.service -or
    @($config.service | Where-Object { $_ -isnot [string] -or [string]::IsNullOrWhiteSpace([string]$_) }).Count -gt 0) {
    throw 'The instance, environment and service settings must be present.'
}
foreach ($directory in @('ready', 'sent', 'suppressed', 'dead')) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $directory) -PathType Container)) {
        throw ('Missing queue directory: ' + $directory)
    }
}
$timeout = [Math]::Max(2, [Math]::Min(60, [int]$config.requestTimeoutSeconds))
$maxEvents = [Math]::Max(1, [Math]::Min(500, [int]$config.maxEventsPerRun))
$resolvedTimeout = 86400
if ($null -ne $config.resolvedTimeoutSeconds) { $resolvedTimeout = [int]$config.resolvedTimeoutSeconds }
if ($resolvedTimeout -lt 1) { throw 'resolvedTimeoutSeconds must be a positive number of seconds.' }
$maxRunSeconds = 240
if ($null -ne $config.maxRunSeconds) { $maxRunSeconds = [int]$config.maxRunSeconds }
if ($maxRunSeconds -lt (2 * $timeout + 10)) { throw 'maxRunSeconds must allow two request timeouts plus ten seconds.' }
$utf8 = [System.Text.UTF8Encoding]::new($false)

function Write-WorkerLog([string]$Message) {
    $line = '[{0}] {1}{2}' -f [DateTime]::UtcNow.ToString('o'), $Message, [Environment]::NewLine
    [System.IO.File]::AppendAllText((Join-Path $root 'worker.log'), $line, $utf8)
}

function Get-Resource([string]$Key) {
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hash = $hasher.ComputeHash($utf8.GetBytes($Key))
        $hex = [System.BitConverter]::ToString($hash).Replace('-', '').ToLowerInvariant()
        return ('veeamone:{0}:alarm:{1}' -f ([string]$config.instance), $hex)
    } finally {
        $hasher.Dispose()
    }
}

function Get-Payload($Record) {
    if ([int]$Record.schemaVersion -ne 1 -or
        [string]::IsNullOrWhiteSpace([string]$Record.captureId) -or
        [string]::IsNullOrWhiteSpace([string]$Record.alarmKey)) {
        throw 'Invalid capture schema or alarm key.'
    }
    $captured = [DateTime]::ParseExact([string]$Record.capturedAtUtc, 'o',
        [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::RoundtripKind)
    if ($captured.Kind -ne [DateTimeKind]::Utc -or [long]$Record.captureSequence -lt 1) {
        throw 'Invalid capture time or sequence.'
    }
    $severity = switch -CaseSensitive ([string]$Record.state) {
        'Error' { 'major' }
        'Warning' { 'warning' }
        'Resolved' { 'normal' }
        default { throw ('Unsupported alarm state: ' + [string]$Record.state) }
    }
    return [ordered]@{
        resource = Get-Resource ([string]$Record.alarmKey)
        event = 'VeeamOneAlarm'
        environment = [string]$config.environment
        service = @($config.service)
        group = [string]$config.group
        origin = [string]$config.origin
        severity = $severity
        timeout = $(if ($severity -eq 'normal') { $resolvedTimeout } else { 0 })
        createTime = $captured.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'", [System.Globalization.CultureInfo]::InvariantCulture)
        value = [string]$Record.state
        text = ('Veeam ONE alarm {0}: {1}' -f [string]$Record.alarmKey, [string]$Record.state)
        attributes = [ordered]@{
            veeamAlarmCombinationId = [string]$Record.alarmKey
            veeamPreviousStatus = [string]$Record.previousState
            capturedAtUtc = [string]$Record.capturedAtUtc
            captureId = [string]$Record.captureId
            captureSequence = [long]$Record.captureSequence
        }
    }
}

function Invoke-Alerta([string]$Json, [string]$ApiKey) {
    $request = [System.Net.HttpWebRequest]([System.Net.WebRequest]::Create($apiUri))
    $request.Method = 'POST'
    $request.ContentType = 'application/json; charset=utf-8'
    $request.Accept = 'application/json'
    $request.AllowAutoRedirect = $false
    $request.Timeout = $timeout * 1000
    $request.ReadWriteTimeout = $timeout * 1000
    $request.Headers['Authorization'] = 'Key ' + $ApiKey
    $bytes = $utf8.GetBytes($Json)
    $request.ContentLength = $bytes.Length
    $response = $null
    try {
        $outgoing = $request.GetRequestStream()
        try { $outgoing.Write($bytes, 0, $bytes.Length) }
        finally { $outgoing.Dispose() }
        try {
            $response = [System.Net.HttpWebResponse]$request.GetResponse()
        } catch [System.Net.WebException] {
            if ($null -eq $_.Exception.Response) {
                return [pscustomobject]@{ Code = 0; Body = ''; Failure = $_.Exception.Status.ToString() }
            }
            $response = [System.Net.HttpWebResponse]$_.Exception.Response
        }
        $body = ''
        $incoming = $response.GetResponseStream()
        if ($null -ne $incoming) {
            $reader = [System.IO.StreamReader]::new($incoming)
            try { $body = $reader.ReadToEnd() }
            finally { $reader.Dispose() }
        }
        return [pscustomobject]@{ Code = [int]$response.StatusCode; Body = $body; Failure = '' }
    } catch [System.Net.WebException] {
        return [pscustomobject]@{ Code = 0; Body = ''; Failure = $_.Exception.Status.ToString() }
    } finally {
        if ($null -ne $response) { $response.Dispose() }
        $request.Abort()
    }
}

function Write-AtomicJson([string]$Path, $Data) {
    $temporary = $Path + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    $bytes = $utf8.GetBytes(($Data | ConvertTo-Json -Depth 8 -Compress))
    $stream = [System.IO.FileStream]::new($temporary, [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    try {
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
    } finally { $stream.Dispose() }
    if (Test-Path -LiteralPath $Path) {
        [System.IO.File]::Replace($temporary, $Path, [System.Management.Automation.Language.NullString]::Value)
    } else {
        [System.IO.File]::Move($temporary, $Path)
    }
}

function Set-Retry([System.IO.FileInfo]$Item, [string]$Reason) {
    $retryPath = $Item.FullName + '.retry'
    $attempts = 0
    if (Test-Path -LiteralPath $retryPath) {
        try {
            $previous = Get-Content -LiteralPath $retryPath -Raw -Encoding UTF8 | ConvertFrom-Json
            $attempts = [int]$previous.attempts
        } catch { $attempts = 0 }
    }
    $attempts++
    $seconds = [int][Math]::Min(3600, (30 * [Math]::Pow(2, [Math]::Min(7, $attempts))))
    $next = [DateTime]::UtcNow.AddSeconds($seconds).ToString('o')
    $data = [ordered]@{ attempts = $attempts; nextAttemptUtc = $next; reason = $Reason }
    Write-AtomicJson $retryPath $data
    Write-WorkerLog ('RETRY {0}: {1}; attempt {2}; next {3}' -f $Item.Name, $Reason, $attempts, $next)
}

function Move-Record([System.IO.FileInfo]$Item, [string]$Folder) {
    $destination = Join-Path (Join-Path $root $Folder) $Item.Name
    if (Test-Path -LiteralPath $destination) {
        # Supports upgrade from the first release's blackout audit-copy behavior.
        $sourceHash = (Get-FileHash -LiteralPath $Item.FullName -Algorithm SHA256).Hash
        $destinationHash = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash
        if ($sourceHash -ne $destinationHash) { throw ('Archive collision: ' + $Item.Name) }
        [System.IO.File]::Delete($Item.FullName)
    } else {
        [System.IO.File]::Move($Item.FullName, $destination)
    }
    $retryPath = $Item.FullName + '.retry'
    if (Test-Path -LiteralPath $retryPath) {
        [System.IO.File]::Delete($retryPath)
    }
}

function Write-Outcome([System.IO.FileInfo]$Item, [string]$Folder, [int]$Code, [string]$Reason, [string]$Body = '') {
    # Protected local diagnostic; never persist the API credential even if a proxy echoes it.
    if (-not [string]::IsNullOrEmpty($apiKey)) { $Body = $Body.Replace($apiKey, '[REDACTED]') }
    if ($Body.Length -gt 4096) { $Body = $Body.Substring(0, 4096) }
    $outcome = [ordered]@{
        processedAtUtc = [DateTime]::UtcNow.ToString('o')
        httpStatus = $Code
        reason = $Reason
        responseExcerpt = $Body
        captureSha256 = (Get-FileHash -LiteralPath $Item.FullName -Algorithm SHA256).Hash
        deliveryContext = [ordered]@{ instance = [string]$config.instance; environment = [string]$config.environment; service = @($config.service); apiUrl = [string]$config.apiUrl }
    }
    Write-AtomicJson (Join-Path (Join-Path $root $Folder) ($Item.Name + '.result.json')) $outcome
}

if ($DryRun) {
    $item = Get-ChildItem -LiteralPath $readyDir -Filter '*.ready' -File |
        Sort-Object Name | Select-Object -First 1
    if ($null -eq $item) { Write-Host 'Queue empty.'; return }
    $record = Get-Content -LiteralPath $item.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
    Get-Payload $record | ConvertTo-Json -Depth 8
    return
}

$mutex = [System.Threading.Mutex]::new($false, 'Global\VeeamOneAlertaWorker')
$lockTaken = $false
try {
    try { $lockTaken = $mutex.WaitOne(0) }
    catch [System.Threading.AbandonedMutexException] { $lockTaken = $true }
    if (-not $lockTaken) { return }
    $runClock = [System.Diagnostics.Stopwatch]::StartNew()

    [System.IO.File]::WriteAllText((Join-Path $root 'last-run.txt'), [DateTime]::UtcNow.ToString('o'), $utf8)
    $encrypted = (Get-Content -LiteralPath ([string]$config.secretPath) -Raw -Encoding UTF8).Trim()
    $secure = ConvertTo-SecureString -String $encrypted
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $apiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    if ([string]::IsNullOrWhiteSpace($apiKey)) { throw 'The decrypted API key is empty.' }

    $items = @(Get-ChildItem -LiteralPath $readyDir -Filter '*.ready' -File | Sort-Object Name | Select-Object -First $maxEvents)
    foreach ($item in $items) {
        if ($runClock.Elapsed.TotalSeconds -ge ($maxRunSeconds - 2 * $timeout)) {
            Write-WorkerLog 'BUDGET reached; leaving remaining ready records for the next scheduled run.'
            break
        }
        $retryPath = $item.FullName + '.retry'
        if (Test-Path -LiteralPath $retryPath) {
            try {
                $retry = Get-Content -LiteralPath $retryPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ([DateTime]::Parse([string]$retry.nextAttemptUtc).ToUniversalTime() -gt [DateTime]::UtcNow) {
                    break  # Global FIFO preserves transition order across a backlog.
                }
            } catch { Write-WorkerLog ('INVALID RETRY STATE {0}; trying again' -f $item.Name) }
        }
        try {
            $record = Get-Content -LiteralPath $item.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $payload = Get-Payload $record
            $json = $payload | ConvertTo-Json -Depth 8 -Compress
        } catch {
            Write-WorkerLog ('DEAD {0}: malformed local record' -f $item.Name)
            Write-Outcome $item 'dead' 0 $_.Exception.Message
            Move-Record $item 'dead'
            continue
        }
        $result = Invoke-Alerta $json $apiKey
        if ($result.Code -eq 200 -or $result.Code -eq 201) {
            try {
                $body = $result.Body | ConvertFrom-Json
                if ($body.status -ne 'ok' -or [string]::IsNullOrWhiteSpace([string]$body.id)) {
                    throw 'Unexpected Alerta response body.'
                }
            } catch {
                Set-Retry $item ('unexpected JSON for HTTP ' + $result.Code)
                break
            }
            Move-Record $item 'sent'
            [System.IO.File]::WriteAllText((Join-Path $root 'last-success.txt'), [DateTime]::UtcNow.ToString('o'), $utf8)
            Write-WorkerLog ('SENT {0}: HTTP {1}; Alerta ID {2}' -f $item.Name, $result.Code, $body.id)
            continue
        }
        if ($result.Code -eq 202) {
            try {
                $body = $result.Body | ConvertFrom-Json
                if ($body.status -ne 'ok' -or $body.message -notlike '*Suppressed*blackout*') {
                    throw 'HTTP 202 response is not an Alerta blackout.'
                }
            } catch {
                Write-WorkerLog ('BLOCKED {0}: unexpected HTTP 202 body' -f $item.Name)
                throw 'Unexpected HTTP 202 response from the receiver.'
            }
            Write-Outcome $item 'suppressed' 202 'Alerta blackout; current-state reconciliation required' $result.Body
            Move-Record $item 'suppressed'
            [System.IO.File]::WriteAllText((Join-Path $root 'last-suppressed.txt'), [DateTime]::UtcNow.ToString('o'), $utf8)
            Write-WorkerLog ('SUPPRESSED {0}: audited Alerta blackout; reconcile current state after maintenance' -f $item.Name)
            continue
        }
        if ($result.Code -eq 400 -or $result.Code -eq 422) {
            Write-Outcome $item 'dead' $result.Code 'Alerta rejected payload' $result.Body
            Move-Record $item 'dead'
            Write-WorkerLog ('DEAD {0}: Alerta rejected payload with HTTP {1}' -f $item.Name, $result.Code)
            continue
        }
        if ($result.Code -eq 0 -or $result.Code -eq 429 -or $result.Code -ge 500) {
            Set-Retry $item ('HTTP ' + $result.Code + ' ' + $result.Failure)
            break
        }
        Write-WorkerLog ('BLOCKED {0}: HTTP {1}; check key, endpoint or redirect' -f $item.Name, $result.Code)
        throw ('Receiver configuration error: HTTP ' + $result.Code)
    }
} catch {
    Write-WorkerLog ('WORKER ERROR: ' + $_.Exception.Message)
    throw
} finally {
    $apiKey = $null
    if ($lockTaken) { $mutex.ReleaseMutex() }
    $mutex.Dispose()
}
