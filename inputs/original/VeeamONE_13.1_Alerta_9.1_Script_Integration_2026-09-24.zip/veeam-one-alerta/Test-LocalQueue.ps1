#requires -Version 5.1
<#
.SYNOPSIS
Runs local regression checks against copies of the production scripts.
.DESCRIPTION
Run only on an isolated Windows test machine where the live Veeam ONE capture
and sender are not running. The copied scripts retain their production global
mutex names. This harness uses a fresh temporary directory, never invokes the
network sender, and neither creates nor reads an API key. It removes its test
directory on completion.

These checks cover parsing, repeated sequence-file replacement, capture order,
invalid-state rejection, missing-sequence rejection, payload mapping, expiry,
and immutable payload identity/time. They do not test HTTPS, DPAPI, scheduling,
ACLs, retries, blackout handling, PostgreSQL, or failover.
.EXAMPLE
powershell.exe -NoLogo -NoProfile -File .\Test-LocalQueue.ps1
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT' -or
    $PSVersionTable.PSEdition -ne 'Desktop' -or
    $PSVersionTable.PSVersion.Major -ne 5 -or
    $PSVersionTable.PSVersion.Minor -ne 1) {
    throw 'Run this regression harness in Windows PowerShell 5.1 on an isolated Windows test machine.'
}

function Assert-Condition([bool]$Condition, [string]$Message) {
    if (-not $Condition) { throw ('Regression failed: ' + $Message) }
}

function Get-Preview([string]$WorkerPath) {
    # -DryRun must return before API-key access and before the HTTP code path.
    $json = (& $WorkerPath -DryRun | Out-String)
    Assert-Condition (-not [string]::IsNullOrWhiteSpace($json)) 'DryRun returned no payload.'
    return ($json | ConvertFrom-Json)
}

$testRoot = $null
try {
    $productionScripts = @(Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.ps1' -File |
        Where-Object { $_.Name -notlike 'Test-*' })
    Assert-Condition ($productionScripts.Count -ge 4) 'Expected the production scripts alongside this harness.'
    foreach ($source in $productionScripts) {
        $tokens = $null
        $parseErrors = $null
        [System.Management.Automation.Language.Parser]::ParseFile(
            $source.FullName, [ref]$tokens, [ref]$parseErrors
        ) | Out-Null
        if ($parseErrors -and $parseErrors.Count -gt 0) {
            $details = ($parseErrors | ForEach-Object {
                '{0}:{1}: {2}' -f $source.Name, $_.Extent.StartLineNumber, $_.Message
            }) -join [Environment]::NewLine
            throw ('Production script parse failure:' + [Environment]::NewLine + $details)
        }
    }

    $testRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('VeeamOneAlerta-regression-' + [Guid]::NewGuid().ToString('N'))
    [System.IO.Directory]::CreateDirectory($testRoot) | Out-Null
    foreach ($source in $productionScripts) {
        Copy-Item -LiteralPath $source.FullName -Destination (Join-Path $testRoot $source.Name)
    }
    $queueRoot = Join-Path $testRoot 'queue'
    foreach ($name in @('ready', 'sent', 'suppressed', 'dead', 'inspected')) {
        [System.IO.Directory]::CreateDirectory((Join-Path $queueRoot $name)) | Out-Null
    }
    $readyRoot = Join-Path $queueRoot 'ready'
    $utf8 = [System.Text.UTF8Encoding]::new($false)
    $config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.example.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $config.instance = 'regression-one'
    $config.apiUrl = 'https://example.invalid/api/alert'
    $config.queueRoot = $queueRoot
    $config.secretPath = Join-Path $testRoot 'nonexistent-key.dpapi'
    $config.environment = 'Regression'
    $config.service = @('Backup')
    $config.group = 'Backup'
    $config.origin = 'VeeamONE/regression-one'
    $config | Add-Member -NotePropertyName resolvedTimeoutSeconds -NotePropertyValue 86400 -Force
    [System.IO.File]::WriteAllText(
        (Join-Path $testRoot 'config.json'), ($config | ConvertTo-Json -Depth 8), $utf8
    )
    $capturePath = Join-Path $testRoot 'Capture-VeeamOneAlarm.ps1'
    $workerPath = Join-Path $testRoot 'Send-VeeamOneQueue.ps1'
    $sequencePath = Join-Path $queueRoot 'capture-sequence.txt'
    $states = @('Error', 'Warning', 'Resolved')
    $previous = @('Resolved', 'Error', 'Warning')
    $severities = @('major', 'warning', 'normal')
    $alarmKey = 'regression-combination-001'

    for ($index = 0; $index -lt $states.Count; $index++) {
        & $capturePath -AlarmKey $alarmKey -State $states[$index] -PreviousState $previous[$index]
    }
    $items = @(Get-ChildItem -LiteralPath $readyRoot -Filter '*.ready' -File | Sort-Object Name)
    Assert-Condition ($items.Count -eq 3) 'Three captures must publish exactly three records.'
    Assert-Condition ([long]::Parse((Get-Content -LiteralPath $sequencePath -Raw).Trim()) -eq 3) 'Sequence-file replacement did not advance to 3.'
    for ($index = 0; $index -lt $items.Count; $index++) {
        $record = Get-Content -LiteralPath $items[$index].FullName -Raw -Encoding UTF8 | ConvertFrom-Json
        Assert-Condition ([long]$record.captureSequence -eq ($index + 1)) 'Filename order must match monotonically increasing capture sequences.'
        Assert-Condition ([string]$record.state -ceq $states[$index]) 'Capture reordered or changed a state.'
        Assert-Condition ([string]$record.alarmKey -ceq $alarmKey) 'Capture changed the alarm key.'
    }

    $invalidRejected = $false
    try { & $capturePath -AlarmKey $alarmKey -State 'InvalidState' -PreviousState 'Error' }
    catch { $invalidRejected = $true }
    Assert-Condition $invalidRejected 'An unsupported state was accepted.'
    Assert-Condition (@(Get-ChildItem -LiteralPath $readyRoot -Filter '*.ready' -File).Count -eq 3) 'Invalid state published a record.'
    Assert-Condition ([long]::Parse((Get-Content -LiteralPath $sequencePath -Raw).Trim()) -eq 3) 'Invalid state consumed a sequence.'

    # A lost counter must not restart numbering while older records exist.
    Remove-Item -LiteralPath $sequencePath
    $missingSequenceRejected = $false
    try { & $capturePath -AlarmKey $alarmKey -State 'Error' -PreviousState 'Resolved' }
    catch { $missingSequenceRejected = $true }
    Assert-Condition $missingSequenceRejected 'A missing sequence with existing records must fail closed.'
    Assert-Condition (@(Get-ChildItem -LiteralPath $readyRoot -Filter '*.ready' -File).Count -eq 3) 'Missing-sequence failure published a record.'
    [System.IO.File]::WriteAllText($sequencePath, '3', $utf8)

    $expectedResource = $null
    for ($index = 0; $index -lt $items.Count; $index++) {
        $before = [System.IO.File]::ReadAllText($items[$index].FullName)
        $record = $before | ConvertFrom-Json
        $payload = Get-Preview $workerPath
        $again = Get-Preview $workerPath
        Assert-Condition ([string]$payload.severity -ceq $severities[$index]) 'Incorrect severity mapping.'
        Assert-Condition ([string]$payload.value -ceq $states[$index]) 'Incorrect payload state.'
        Assert-Condition ($null -ne $payload.PSObject.Properties['timeout']) 'Payload must explicitly set timeout.'
        $expectedTimeout = if ($states[$index] -eq 'Resolved') { 86400 } else { 0 }
        Assert-Condition ([int]$payload.timeout -eq $expectedTimeout) 'Incorrect active/resolved alert timeout.'
        Assert-Condition ([string]$payload.createTime -cmatch '^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$') 'createTime must be UTC with exactly three fractional digits.'
        $capturedAt = [DateTime]::Parse(
            [string]$record.capturedAtUtc,
            [System.Globalization.CultureInfo]::InvariantCulture,
            [System.Globalization.DateTimeStyles]::RoundtripKind
        )
        $expectedTime = $capturedAt.ToUniversalTime().ToString(
            "yyyy-MM-dd'T'HH:mm:ss.fff'Z'", [System.Globalization.CultureInfo]::InvariantCulture
        )
        Assert-Condition ([string]$payload.createTime -ceq $expectedTime) 'createTime must derive from the saved capture time.'
        Assert-Condition ([string]$again.createTime -ceq [string]$payload.createTime) 'Repeated preview changed createTime.'
        Assert-Condition ([string]$again.resource -ceq [string]$payload.resource) 'Repeated preview changed resource identity.'
        Assert-Condition ([string]$payload.resource -cmatch '^veeamone:regression-one:alarm:[0-9a-f]{64}$') 'Unexpected resource format.'
        if ($null -eq $expectedResource) { $expectedResource = [string]$payload.resource }
        Assert-Condition ([string]$payload.resource -ceq $expectedResource) 'The same alarm key must keep one resource across severity transitions.'
        Assert-Condition ([string]$payload.event -ceq 'VeeamOneAlarm') 'Event identity changed.'
        Assert-Condition ([string]$payload.environment -ceq 'Regression') 'Environment identity changed.'
        Assert-Condition ([System.IO.File]::ReadAllText($items[$index].FullName) -ceq $before) 'DryRun modified the saved record.'
        Assert-Condition (-not (Test-Path -LiteralPath $config.secretPath)) 'DryRun unexpectedly created a secret.'
        Assert-Condition (-not (Test-Path -LiteralPath (Join-Path $queueRoot 'last-run.txt'))) 'DryRun entered the sending path.'
        # Advance only this temporary queue so the next DryRun previews the next state.
        Move-Item -LiteralPath $items[$index].FullName -Destination (Join-Path (Join-Path $queueRoot 'inspected') $items[$index].Name)
    }
    Write-Output ('PASS: parsed {0} production scripts; sequential capture/replacement, rejection, severity, expiry, immutable identity/time, and DryRun checks passed.' -f $productionScripts.Count)
    Write-Output 'No API key or network sender was used. Live delivery and failover still require separate acceptance tests.'
} finally {
    if ($null -ne $testRoot -and (Test-Path -LiteralPath $testRoot)) {
        try { Remove-Item -LiteralPath $testRoot -Recurse -Force }
        catch { Write-Warning ('Could not remove the regression temporary directory: ' + $testRoot) }
    }
}
