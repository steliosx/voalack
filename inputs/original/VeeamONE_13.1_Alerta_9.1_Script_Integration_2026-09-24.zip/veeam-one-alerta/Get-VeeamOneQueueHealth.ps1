[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$root = [string]$config.queueRoot
$ready = @(Get-ChildItem -LiteralPath (Join-Path $root 'ready') -Filter '*.ready' -File)
$dead = @(Get-ChildItem -LiteralPath (Join-Path $root 'dead') -Filter '*.ready' -File)
$suppressed = @(Get-ChildItem -LiteralPath (Join-Path $root 'suppressed') -Filter '*.ready' -File)
$tempReady = @(Get-ChildItem -LiteralPath (Join-Path $root 'ready') -Filter '*.tmp' -File)
$tempAudit = @(Get-ChildItem -LiteralPath (Join-Path $root 'suppressed') -Filter '*.tmp' -File)
$tempDead = @(Get-ChildItem -LiteralPath (Join-Path $root 'dead') -Filter '*.tmp' -File)
$tempSent = @(Get-ChildItem -LiteralPath (Join-Path $root 'sent') -Filter '*.tmp' -File)
$tempSequence = @(Get-ChildItem -LiteralPath $root -Filter 'capture-sequence-*.tmp' -File)
$temporary = @($tempReady + $tempAudit + $tempDead + $tempSent + $tempSequence)
$oldestTemporary = $temporary | Sort-Object CreationTimeUtc | Select-Object -First 1
$oldest = $ready | Sort-Object CreationTimeUtc | Select-Object -First 1
$lastSuppressed = Join-Path $root 'last-suppressed.txt'
$lastRun = Join-Path $root 'last-run.txt'
$lastSuccess = Join-Path $root 'last-success.txt'
$record = [ordered]@{
    readyCount = $ready.Count
    deadCount = $dead.Count
    suppressedCount = $suppressed.Count
    temporaryCount = $temporary.Count
    oldestTemporaryAgeSeconds = $(if ($null -eq $oldestTemporary) { 0 } else { [int]([DateTime]::UtcNow - $oldestTemporary.CreationTimeUtc).TotalSeconds })
    lastSuppressedUtc = $(if (Test-Path -LiteralPath $lastSuppressed) { (Get-Content -LiteralPath $lastSuppressed -Raw).Trim() } else { $null })
    oldestReadyAgeSeconds = $(if ($null -eq $oldest) { 0 } else { [int]([DateTime]::UtcNow - $oldest.CreationTimeUtc).TotalSeconds })
    lastRunUtc = $(if (Test-Path -LiteralPath $lastRun) { (Get-Content -LiteralPath $lastRun -Raw).Trim() } else { $null })
    lastSuccessUtc = $(if (Test-Path -LiteralPath $lastSuccess) { (Get-Content -LiteralPath $lastSuccess -Raw).Trim() } else { $null })
}
$record | ConvertTo-Json -Compress
