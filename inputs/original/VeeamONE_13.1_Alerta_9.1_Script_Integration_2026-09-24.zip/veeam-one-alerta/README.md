# Veeam ONE 13.1 → Alerta 9.1: notification-script starter

Revision 2 — corrected after an independent GPT-6 Astra Ultra review on 24 September 2026. Static review only; Windows and live-system acceptance remain outstanding. Target Veeam ONE build: **13.1.0.7233**. Target Alerta: **9.1.0**. This package uses PowerShell 5.1 on the Windows Veeam ONE server and the existing internal Alerta HTTPS API. No changes to PostgreSQL, Patroni, etcd or PgBouncer are required.

## What the starter does

1. Veeam ONE invokes `Capture-VeeamOneAlarm.ps1` from an alarm's **Notifications → Run script** action. The capture script serializes local invocations with a named mutex and a persisted sequence number, writes a small UTF-8 JSON record to a temporary file, flushes it to disk, and renames it into a local ready queue. It never makes an HTTP request.
2. `Send-VeeamOneQueue.ps1`, run every minute by Task Scheduler, reads ready records in filename order. It calls `https://<your-alerta-fqdn>/api/alert` via the internal NetScaler → Nginx → Alerta path. It does not follow HTTP redirects and checks for an Alerta JSON response.
3. The worker archives accepted records, separates blackout-suppressed records, retries temporary failures with exponential backoff, and quarantines malformed events. Once capture has successfully published a record, the local queue survives a worker restart or loss of the Alerta API. A capture failure (disk full, ACL, or Veeam script failure) needs an independent alarm.

The script action in this Veeam ONE build documents **Error, Warning and Resolved** under **Any state**. It does **not** document Info or operator Acknowledged script events. This starter reports the three documented states. Veeam ONE REST state reconciliation is the next step for Info, acknowledgments, and missed transitions. The `%7` argument identifies an affected-node/alarm combination; it is **not** guaranteed to identify each job within a grouped alarm. Start with one Alerta alert per `%7`, and validate child-alarm behavior before promising per-job incidents.

## How this fits your current Alerta deployment

```mermaid
flowchart TB
  ONE["Veeam ONE Windows server"] -->|"HTTPS 443, API key"| GSLB["<your-alerta-fqdn>:443"]
  GSLB --> SITEA["site-A NetScaler → Nginx → Alerta pool"]
  GSLB --> SITEB["site-B NetScaler → Nginx → Alerta pool"]
  SITEA --> PGN["Local PgBouncer 127.0.0.1:6432"]
  SITEB --> PGY["Local PgBouncer 127.0.0.1:6432"]
  PGN --> VIPN["site-A writer VIP → Patroni primary"]
  PGY --> VIPY["site-B writer VIP → Patroni primary"]
  VIPN --> DB["PostgreSQL 18: site-A / site-B"]
  VIPY --> DB
  DCS["etcd quorum: site-A / site-B / site-C"] -->|"leader election"| DB
```

The latest Alerta implementation diagram records application nodes `<site-A-app-node-ips>` (site-A) and `<site-B-app-node-ips>` (site-B); PostgreSQL/Patroni nodes `<site-A-db-node-ip>` and `<site-B-db-node-ip>`; and etcd voters `<site-A-etcd-ip>`, `<site-B-etcd-ip>`, `<site-C-etcd-ip>`. Its site-A and site-B writer VIPs `<site-A-writer-vip>` and `<site-B-writer-vip>` are **proposed allocations to confirm**, not verified live IPs. The diagram also says the four PgBouncers were reported to use transaction mode and `<db-writer-vip-name>`; session mode with site-local writer names is a proposed target, not an established live setting. Do not change the database or pool mode for this integration. The latest simplified RBAC guide sets `CUSTOMER_VIEWS = False`, so the starter sends internal source-wide alarms without a tenant/customer field. Revisit explicit customer mapping and API key routing before enabling customer views.

| Source | Destination | Port | Purpose |
|---|---|---:|---|
| Veeam ONE Monitoring Service host (confirm its source IP) | Internal `<your-alerta-fqdn>` application GSLB / active HTTPS VIP | TCP 443 | Alerta JSON API ingestion; preserve `Authorization` through ADC and Nginx |
| Alerta process on each of four app nodes | PgBouncer on **the same app node** | Loopback TCP 6432 | Existing application database path; no new Veeam rule |
| Local PgBouncer | Existing writer VIP for its site | TCP 5432 | Existing database path; no new Veeam rule |
| Patroni/database nodes | Existing etcd members | TCP 2379 | Existing etcd client access; no Veeam access |
| etcd members | Other etcd members | TCP 2380 | Existing quorum peer traffic; no Veeam access |

Veeam ONE needs **no** direct access to PgBouncer, PostgreSQL, Patroni or etcd. Preserve the existing `/api` path on Nginx, forward the `Authorization` header, and use a readiness monitor that traverses the application's database path. Alerta documents `/api/management/gtg` as database-aware; `/api/management/healthcheck` also evaluates heartbeats and can report unhealthy while alert writes remain available. Validate the actual deployed proxy route before changing an ADC monitor.

The intended receiver-side configuration to **verify**, rather than overwrite as part of this change, is:

```python
# /etc/alertad.conf (same application policy on all four Alerta nodes)
DATABASE_URL = 'postgresql://<app-user>:<URL-encoded-secret>@127.0.0.1:6432/alerta?connect_timeout=10'
AUTH_REQUIRED = True
USER_DEFAULT_SCOPES = ['read:alerts']
ADMIN_ROLES = ['admin']
DELETE_SCOPES = ['delete:alerts']
CUSTOMER_VIEWS = False
```

Keep the current database name `alerta` unless a separate, approved database cutover changes it. The exact user, TLS settings, active PgBouncer mode and backend writer name must be checked against each running app node. The Veeam sender only depends on the resulting HTTPS API health.

## Installation on the Veeam ONE Windows host

1. Copy the four production `.ps1` files (`Capture-VeeamOneAlarm.ps1`, `Send-VeeamOneQueue.ps1`, `Set-AlertaKey.ps1`, `Get-VeeamOneQueueHealth.ps1`) into `C:\ProgramData\VeeamOneAlerta\`. Copy `config.example.json` there as `config.json`. Set `instance` to a unique **stable** Veeam ONE instance name. Confirm `apiUrl` resolves and reaches the **internal** Alerta API without a Duo login redirect. Keep the sample environment `Production`, service `Backup`, and group `Backup` unless your Alerta configuration uses different values.
2. Create `C:\ProgramData\VeeamOneAlerta\queue\ready`, `sent`, `suppressed`, `dead`, and `C:\ProgramData\VeeamOneAlerta\secret`. Keep the queue and its temporary files on the same local NTFS volume; allow for the volume's fault tolerance and backup policy. Do **not** place the queue on the VSA, on PgBouncer, or inside the Alerta PostgreSQL database. Preserve `queue\capture-sequence.txt` across routine reinstalls; resetting it while old records remain can reorder records. Capture now rejects a missing counter when ready or archived records exist. Restore the counter from a consistent backup; do not invent a low value. Keep the counter even after archive cleanup.
3. Inspect **Windows Services → Veeam ONE Monitoring Service → Log On**. Give that identity read/execute on `Capture-VeeamOneAlarm.ps1` and `config.json`, **Modify** on the queue root (for its durable sequence file and best-effort failure log), and Modify on `queue\ready`. Give the worker **Modify** on the queue root and its four directories; give only the worker and Administrators read access to the API secret. Remove inherited broad user access. Only the administrative deployment identity and Administrators may modify the installed scripts or `config.json`; both runtime identities need read/execute only on those files. Verify effective access under both accounts, including inherited permissions. Queue write access does not require write access to the installation directory or secret directory. After verifying the package, unblock its downloaded `.ps1` files if Windows marks them as remote. The command examples use process-scope `RemoteSigned`; if Group Policy requires `AllSigned`, sign the scripts and use the policy it allows.
4. In Alerta, issue a **dedicated integration API key** whose permissions include `write:alerts`. Do not reuse the read-only key for your Zabbix inventory export. Keep human Duo/OIDC login separate from API-key authentication. For this starter, use an ordinary dedicated Windows worker account that can sign in interactively for initial provisioning; sign in **as that same account**, then run `Set-AlertaKey.ps1`. Its DPAPI-encrypted file is readable only by that Windows identity on this host. Apply restrictive file ACLs. A gMSA or account prohibited from interactive sign-in needs a different approved key-provisioning method before using this package. An account switch, host rebuild, or moving the worker to another server requires re-provisioning the key.
5. Register a Task Scheduler task as that worker account. Run `C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe` with arguments `-NoLogo -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File "C:\ProgramData\VeeamOneAlerta\Send-VeeamOneQueue.ps1"`. Trigger **every minute**; set **If the task is already running: Do not start a new instance**; allow it to run whether a user is logged on, with stored credentials rather than the passwordless/S4U task option so the user-profile DPAPI key can be read. Allow network access and set a reasonable execution limit (for example five minutes). The worker has a soft `maxRunSeconds=240` budget and stops starting requests before that budget is used; an in-flight request or slow filesystem can still exceed it. Keep the scheduler hard limit above that budget. Run the task once and verify it decrypts the key under its actual account. The worker also takes a named mutex.
6. In the Veeam ONE Client choose a test alarm under **Alarm Management → Edit → Notifications → Add → Run script**, set **Condition = Any state**, and paste this entire line into **Value**:

   ```text
   C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy RemoteSigned -File "C:\ProgramData\VeeamOneAlerta\Capture-VeeamOneAlarm.ps1" "%7" "%5" "%6"
   ```

   This passes only the stable combination ID and current/previous states. Avoid passing `%3` (free-text summary) through a Windows command line. If your Veeam ONE build or alarm leaves `%7` empty, capture raises an error so the collision is visible; investigate that alarm instead of fabricating an identifier. This is **Notifications → Run script**, not **Actions → Run Script** (which has different placeholder meanings). If you want names in Alerta, add reviewed REST enrichment after validating how `%7` matches the API's `triggeredAlarmId` for your alarm types.
7. First run `Test-LocalQueue.ps1` with Windows PowerShell 5.1 on an **isolated test Windows machine**, with the production scripts and `config.example.json` alongside it. It uses temporary copies, three consecutive captures, negative checks, native parsing, and DryRun payload assertions. It has not been executed in the preparation environment. Do not run it alongside live capture/worker processes because their global mutex names are shared. You can smoke-test the local queue first (replace the path if needed): `& 'C:\ProgramData\VeeamOneAlerta\Capture-VeeamOneAlarm.ps1' 'TEST-ONE-001' 'Error' 'Resolved'`. Run `& 'C:\ProgramData\VeeamOneAlerta\Send-VeeamOneQueue.ps1' -DryRun` to preview its JSON without sending or moving the file. Then run a **real Veeam alarm** Error → Warning → Resolved cycle and confirm a file is written for each change. Run the worker normally. In Alerta, verify that one stable resource changes severity and Resolved sends `normal` to close it. Repeat with two child jobs under one parent to check the intended aggregation. Close the test alert through a matching Resolved test event.

The Veeam **%4** placeholder is an alarm trigger time, not a state-transition timestamp. This package timestamps each invocation locally instead and does not claim to reconstruct a complete source history.

## Alerta receiver configuration

The worker sends JSON with `environment=Production`, `service=["Backup"]`, `group=Backup`, `event=VeeamOneAlarm`, and `resource=veeamone:<instance>:alarm:<SHA-256 of %7>`. Error becomes `major`, Warning `warning`, and Resolved `normal`. The original `%7` and prior state are preserved in `attributes`. Active Error/Warning messages explicitly send `timeout=0`, preventing default expiry without a source clear. Resolved sends the finite `resolvedTimeoutSeconds` value (default 86400), allowing standard housekeeping to age out closed alerts. This makes monitoring and reconciliation of missed clear events essential. Each POST uses the saved local capture timestamp for `createTime`, in UTC milliseconds; retries preserve that timestamp. Synchronize the Windows host clock. A fixed resource and event make repeat sends converge on the same Alerta alert; no `correlate` list is used.

Keep the approved human RBAC settings (`USER_DEFAULT_SCOPES=['read:alerts']`, engineering roles with `write:alerts` but no delete, `DELETE_SCOPES=['delete:alerts']`, and `CUSTOMER_VIEWS=False`) as documented in `Alerta_Simplified_RBAC_2026-09-23.docx`. The sender key is a separate machine credential. If Alerta's default reject plugin is enabled, `Production` and the `service` list satisfy its required fields.

A validated Alerta HTTP **202** means intentional blackout suppression, not a stored alert. The worker moves that event to `queue\suppressed`, writes a diagnostic sidecar, and continues with unrelated events. It does **not** retry a suppressed historical event. Alerta evaluates blackouts using the event creation time, so changing the timestamp on retry would change its meaning. For this transition-only starter, avoid blackouts that match this feed until current-state reconciliation is available. If maintenance suppression is required, review the existing receiver policy to allow clear severities (`BLACKOUT_ACCEPT = ['normal', 'ok', 'cleared']`) and reconcile every affected identity against Veeam after maintenance. This is a policy change to evaluate across existing integrations, not a setting to overwrite blindly. `NOTIFICATION_BLACKOUT=True` stores an alert with blackout status and suppresses downstream notifications, but a persistent error still needs a fresh current-state observation to leave blackout status after the window ends. No automatic current-state reconciler is included. A 200 or 201 counts only when the body is Alerta JSON containing a status of `ok` and alert ID. The worker does **not** follow 3xx redirects: a Duo login page must never look like a successful API delivery.

## Recovery, monitoring, and limits

- Monitor `Get-VeeamOneQueueHealth.ps1` from Zabbix 7 for `readyCount`, `oldestReadyAgeSeconds`, `deadCount`, `temporaryCount`, `oldestTemporaryAgeSeconds`, `lastRunUtc`, and `lastSuccessUtc`. Alert on persistent temporary files (for example older than two minutes), old queue items, any dead letters, no worker run, or a failed Task Scheduler run. `suppressedCount` is **historical** because suppressed events remain as evidence: alert on an increase or a recent `lastSuppressedUtc`, not on a count greater than zero forever. Check `capture-failures.log` and `%ProgramData%\Veeam\Veeam ONE\Logs\` for notification script failures. A canary should verify the actual Veeam notification action as well as the local spool; a working task alone cannot prove Veeam is invoking it. Monitor disk free space and set an operational archive cleanup policy after retaining the evidence you need. Keep the ONE server and both Alerta application sites independently monitored.
- A network timeout, HTTP 429, or HTTP 5xx leaves the head item in `ready` with an exponential retry delay. This stops younger records during a retry, preserving **local invocation order** across a backlog with the durable capture sequence. Veeam does not publish a source sequence number, so the true order of source transitions before each script invocation is not guaranteed. Reconciliation against current ONE state is required after an outage or large backlog. HTTP 401/403, 404 and redirects leave the queue in place and require fixing the receiver/key. A malformed event or 400/422 goes to `dead`, with a bounded diagnostic `.result.json` sidecar for inspection. **Do not blindly move old dead, suppressed or sent files back into `ready`:** a stale Error can reopen an alert after a newer Resolved has already been delivered. Compare current Veeam state and all later captures for that identity, fix the cause, and emit a fresh reconciled observation if needed; preserve the historical record as evidence. Archive retention is an operator policy; this starter does not auto-delete evidence.
- Freeze `instance`, `environment` and other identity/routing settings while queued records exist: this starter builds the payload using the current config at send time. Changing identity requires draining or deliberately migrating the backlog and reconciling the old/new Alerta identities. Never point the same ready queue at two independent workers.
- A crash after Alerta accepts a POST but before the local move can resend the record. Alerta's stable identity limits duplicate incidents, but repeat counters or notes may change. This design is **at least once after successful local spooling**, not end-to-end exactly once.
- Delayed observations and retries can interact with operator acknowledgments made after capture. Preserving capture time does not guarantee that Alerta's history/state transitions preserve every later operator action. Test an acknowledgment during a backlog followed by a severity change and an accepted-POST retry; reconcile current source state if the result differs from your operating policy.
- The capture mutex waits at most 30 seconds. Load-test the expected alarm burst under the actual Veeam ONE Monitoring Service identity; a timeout raises an error and should create a best-effort `capture-failures.log` line. A full disk can prevent even that failure log, which is why a Veeam action canary and disk monitoring are necessary.
- `%7` can aggregate more than one child job, and Veeam ONE acknowledgment generates no script response. Add a read-only ONE REST reconciler against `https://<one-web-services>:1239/api/v2.3/alarms/triggeredAlarms` (and child endpoint) before depending on exact Info/ACK state, child identity, or recovery after extended capture outages. Do not treat a missing row as Resolved without understanding pagination/retention. After a large backlog or blackout, reconcile the current state rather than trusting transition order alone.
- If PostgreSQL/Patroni/etcd/PgBouncer fail, Alerta may stop accepting writes; the ONE-local queue holds captured events until the Alerta API returns. Verify the existing writer VIPs select only Patroni's primary, that local PgBouncer connects to the active writer, and that the three etcd voters have quorum. Those are **receiver health checks**, not connections or configuration changes made by this package.

## Acceptance checks

| Exercise | Expected result |
|---|---|
| Three local captures in succession | Sequence replacement succeeds; records have sequences 1, 2, 3 |
| Error → Warning → Resolved | Same Alerta `resource` and `event`; severity updates to `major`/`warning`/`normal` |
| Stop Alerta API or block worker's HTTPS route | Capture continues, `readyCount` rises, then queue drains after recovery |
| Return an HTML login redirect | Queue stays ready; worker reports a configuration error |
| Blackout one identity, then queue an unrelated identity | First record moves to `suppressed`; unrelated record is delivered; reconcile maintenance state afterward |
| Error remains unchanged beyond 24 hours | Error remains active with timeout 0; confirm housekeeping does not expire it |
| Resend same severity after acknowledgment, without an older delayed transition | Default Alerta model preserves acknowledgment; normal still closes it |
| Delay an Error behind an operator ACK, then repeat after accepted-POST interruption | Check resulting severity/status against policy; upstream history ordering can restore ACK on retry; reconcile current state |
| Return 400 on one record | Record and diagnostic sidecar appear in `dead`; review current source state before any recovery |
| Kill worker after accepted POST | Record may be resent; no second unrelated Alerta resource |
| Fail site-A app site | GSLB selects site-B; worker reaches same API name; database writer path remains healthy |
| Fail PgBouncer or PostgreSQL writer | API readiness/worker reports failure; queue waits for recovery |

## Upgrading the first starter package

Perform file replacement in a controlled interval with the worker stopped and no capture script executing; account for any source transitions during that interval in the subsequent current-state review. Preserve all queue contents, the counter, the secret and your configured identity, and copy the revised production scripts. Add the two new optional settings from `config.example.json`: `resolvedTimeoutSeconds=86400` and `maxRunSeconds=240`. Existing schema-version-1 queue records remain readable. A suppressed audit copy from the first revision can coexist with its ready original; the new worker verifies SHA-256 equality before completing the terminal move. A differing archive copy stops processing for investigation. Existing `.retry` delays remain in effect until due.

The new timeout policy affects newly delivered messages; already stored active alerts are not retroactively corrected. Review those against Veeam and send fresh current-state observations as appropriate. The updated sender also gives existing queued records their original capture time, so some previously queued events can correctly receive blackout suppression. Review this before resuming a maintenance backlog.

## Sources

- Veeam ONE 13.1 User Guide: [alarm notification options](https://helpcenter.veeam.com/docs/one/userguide/alarm_notifications.html), [latest build](https://www.veeam.com/products/downloads/latest-version.html), [triggered alarms REST reference](https://helpcenter.veeam.com/references/one/13/rest/tag/Alarms/).
- Alerta 9.1: [API reference](https://docs.alerta.io/api/reference.html), [alert customization](https://docs.alerta.io/gettingstarted/tutorial-4-customisation.html), [configuration](https://docs.alerta.io/configuration.html).
- Existing Alerta documentation: `Alerta_Implementation_Diagrams.html` and `Alerta_Simplified_RBAC_2026-09-23.docx` (the latest current-state notes used for this package).

- Microsoft: [PowerShell NullString](https://learn.microsoft.com/en-us/dotnet/api/system.management.automation.language.nullstring?view=powershellsdk-7.6.0), [File.Replace](https://learn.microsoft.com/en-us/dotnet/api/system.io.file.replace?view=netframework-4.8.1).
- Alerta pinned source: [v9.1.0 PostgreSQL backend](https://github.com/alerta/alerta/blob/v9.1.0/alerta/database/backends/postgres/base.py), [v9.1.0 blackout plugin](https://github.com/alerta/alerta/blob/v9.1.0/alerta/plugins/blackout.py).
