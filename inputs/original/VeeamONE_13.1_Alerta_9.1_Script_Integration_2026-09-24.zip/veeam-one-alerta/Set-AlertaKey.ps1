# Run interactively as the SAME Windows identity that will run the scheduled worker.
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$config = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$path = [string]$config.secretPath
if (-not (Test-Path -LiteralPath (Split-Path -Parent $path) -PathType Container)) {
    throw 'Create the protected secret directory and its ACL before provisioning the API key.'
}
if (Test-Path -LiteralPath $path) {
    throw 'A key file already exists. Move it aside explicitly before rotating the key.'
}
$secret = Read-Host 'Paste the dedicated Alerta write:alerts API key' -AsSecureString
$encrypted = ConvertFrom-SecureString -SecureString $secret
[System.IO.File]::WriteAllText($path, $encrypted, [System.Text.UTF8Encoding]::new($false))
Write-Host 'The API key was stored with Windows DPAPI. Verify the secret-file ACL.'
