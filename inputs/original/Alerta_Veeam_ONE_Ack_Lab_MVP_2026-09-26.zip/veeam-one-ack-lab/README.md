# Alerta → Veeam ONE acknowledgment: lean lab MVP

26 September 2026 · package 0.1.0 · Alerta 9.1.0 · Veeam ONE 13.1 / REST 2.3

## Recommendation

Use a small Alerta server plugin for a **single-node lab**. A human operator acknowledges an alert normally in Alerta; after Alerta saves that action, the plugin acknowledges one explicitly mapped Veeam ONE alarm and includes the operator's identity and message in its comment. The result appears in the Alerta alert's **Notes** tab.

No additional VM, broker, scheduled poller or database schema is needed. Your PostgreSQL/Patroni/etcd/PgBouncer setup continues to serve Alerta normally. The only new network path is the selected Alerta lab application host → Veeam ONE Web Services, HTTPS TCP 1239 by default.

Veeam supports this operation natively. No maintained Veeam write-back connector was found in the official Alerta plugin/contrib catalog reviewed. This is a custom lab plugin, not a vendor-supported connector.

| Option | Fit |
|---|---|
| This direct Alerta plugin | Leanest way to prove ACK + comment from the normal operator workflow; one lab node, explicit mappings, manual retry |
| Plugin + durable outbox + one worker | Next step for your four-node/two-site production application tier; use an audited shared queue and a single owner for ONE API sessions |
| Poll Alerta for acknowledged alerts | Avoids a server plugin, but adds a service and delayed observation; can miss short-lived actions or lose precise action attribution |
| Veeam Service Provider Console | Has its own Veeam ONE alarm synchronization; adding it solely to bridge Alerta is unnecessary for this lab |

## What the operator sees

1. Sign in to Alerta normally through your configured identity provider.
2. Open an approved test alert and acknowledge it, adding text such as `Investigating backup proxy connectivity`.
3. Alerta saves the local acknowledgment under the human user.
4. The plugin reads current ONE state, checks the administrator-owned binding, sends the ACK when permitted, and reads the result back.
5. Refresh the alert's Notes tab. The integration records `dry-run`, `confirmed`, `already-acknowledged`, `blocked`, `failed` or `uncertain`.

Example ONE comment:

```text
[AlertaAck:<correlation-id>] Alerta=<alert-uuid> operator=engineer@example.com; Investigating backup proxy connectivity
```

Veeam's authenticated API identity remains the dedicated service account. The human actor is attributed in the comment; this does not impersonate that user in Veeam.

```mermaid
sequenceDiagram
  participant U as Operator
  participant A as Alerta
  participant P as ACK plugin
  participant V as Veeam ONE
  U->>A: Acknowledge with message
  A->>A: Check permission and save ACK
  A->>P: Post-action hook
  P->>V: Read and validate mapped alarm
  alt Dry run or binding rejected
    P->>A: Outcome note
  else Approved live attempt
    P->>V: Acknowledge with actor and comment
    P->>V: Read back status and comment
    P->>A: Confirmed or uncertain note
  end
```

The integration outcome note is written directly to Alerta's notes model. It deliberately does not append a status-history row or replace the alert's attributes: either could interfere with newer incoming source state. This uses an internal Alerta model API tested against 9.1.0, so revalidate it when upgrading Alerta.

## Supported operations and permissions

The ONE operation is:

```http
POST /api/v2.3/alarms/triggeredAlarms/resolve
Authorization: Bearer <service-account-token>
Content-Type: application/json

{
  "triggeredAlarmIds": [1253],
  "resolveType": "Acknowledge",
  "comment": "[AlertaAck:...] Alerta=... operator=...; Investigating"
}
```

Despite the path's name, `resolveType: Acknowledge` acknowledges the problem; it does not resolve it or run remediation. The comment limit is 1024 characters; the client conservatively bounds UTF-16 length. A successful HTTP 200 may have an empty body, so the client verifies with a separate GET.

No standalone comment-only alarm endpoint was found in the current public ONE alarm API. This MVP adds a comment **with the acknowledgment**. It does not re-ACK an already acknowledged alarm simply to overwrite its comment. Alerta notes remain available for later discussion. Do not substitute `resolveType: Action` for a comment operation.

| Identity | Requirement |
|---|---|
| Alerta default/read-only user | Can view; cannot invoke the ACK/action route |
| Service Desk/Escalation engineer | Existing `write:alerts` permits ACK and custom retry; no `delete:alerts` is needed |
| Human Alerta identity | Plugin requires server-authenticated `g.user_id` and `g.login`; it ignores API-key and unauthenticated contexts |
| ONE integration account | **Veeam ONE Administrator** is required by the documented Alarms POST permissions; Power User/Read-Only cannot perform the operation |

Keep your existing `CUSTOMER_VIEWS=False` and engineer permission mappings. The ONE role requirement does **not** imply Windows/domain administrator privileges. In ONE Web Client, use Configuration → Access Management → Users and Groups to assign a dedicated account the ONE Administrator role. Do not reuse an account used by another integration or an interactive operator: Veeam documents possible session interference.

This MVP authenticates with username/password to `/api/token` and revokes its token afterward. It does not implement an MFA challenge. Use an account/authentication policy approved for unattended lab integration; if interactive MFA is required for that account, this version cannot perform unattended ACK. Human Duo/OIDC access to Alerta stays as configured.

## Scope and identity binding

Start with **one non-grouped test alarm** where `childAlarmsCount=0`. Grouped parent alarms and child-object alarms are rejected. Many backup-job alarms are grouped; this MVP does not promise per-job ACK for those. The API supports child endpoints, but they need an independently verified child-identity mapping before being enabled.

Our earlier PowerShell sender already supplies `event=VeeamOneAlarm`, a hashed `resource`, `attributes.veeamAlarmCombinationId` and `attributes.captureId`. No sender change is needed for this lab. The `%7` combination value is **not assumed to equal** REST `triggeredAlarmId`.

An administrator explicitly maps the Alerta alert UUID and exact source capture to the correct REST target in `config/veeam-one-ack.example.json`. The mapping also pins resource, event, environment, origin, alarm template, source object, trigger time and repeat count. Every new source capture requires a binding review in this deliberately narrow MVP. This limits it to a handful of test alarms, not unattended fleet operation.

Alert attributes are writable by Alerta engineers. They therefore cannot supply arbitrary target URLs or select arbitrary Veeam alarm IDs. Only the administrator-managed config selects those. The mapping proves what was approved for the lab; it does not make mutable source attributes cryptographically trusted.

## Install on one isolated Alerta lab node

Assume an existing working Alerta 9.1.0 installation with Python 3.11 or newer (tested here on 3.12). The package adds no Python runtime dependency outside Alerta and the standard library. The example service user/group is `alerta`; substitute the actual account and Python virtual environment used by your uWSGI/Gunicorn/Alerta service. Inspect its service unit and virtual-environment setting first.

1. Unzip the bundle, inspect the code/runbook and verify `SHA256SUMS.txt` if desired. Install the supplied wheel using **Alerta's own Python environment**, without upgrading its dependencies:

   ```bash
   /opt/alerta/venv/bin/python -m pip install --no-deps dist/alerta_veeam_one_ack_lab-0.1.0-py3-none-any.whl
   ```

2. Create protected configuration and runtime directories. Example for user/group `alerta`:

   ```bash
   sudo install -d -o root -g alerta -m 0750 /etc/alerta
   sudo install -o root -g alerta -m 0640 config/veeam-one-ack.example.json /etc/alerta/veeam-one-ack.json
   sudo install -d -o alerta -g alerta -m 0700 /run/alerta-veeam-one
   ```

   Use `sudoedit /etc/alerta/veeam-one-ack.password` to enter the dedicated account's password on one line, then set owner `root:alerta` and mode `0640`. Do not put the password in shell arguments, alert attributes, the ZIP or an operator message. Keep configuration and installed code writable only by deployment administrators; the Alerta process needs read access. Install your ONE CA chain at the configured `ca_file`, or set it to `null` to use the operating system's trusted CA store. TLS verification cannot be disabled by this client.

   To recreate the runtime directory after reboot, add this line to `/etc/tmpfiles.d/alerta-veeam-one.conf`, substituting the actual account, then run `sudo systemd-tmpfiles --create /etc/tmpfiles.d/alerta-veeam-one.conf`:

   ```text
   d /run/alerta-veeam-one 0700 alerta alerta -
   ```

3. Edit `/etc/alerta/veeam-one-ack.json`. Set `one_url` to the actual ONE **Web Services** HTTPS origin, account, CA and password-file paths. Keep `dry_run: true`. Start with `bindings: {}`; the supplied UUIDs/IDs are fictitious examples, not discovered values. This file is reloaded on each action.

4. Allow HTTPS from **this lab app host** to ONE Web Services on TCP 1239, or its configured port. No new app-to-Postgres/Patroni/etcd/PgBouncer rule is required. Do not route this API call through a human SSO redirect. The client refuses redirects and does not use environment-configured HTTP proxies.

5. Merge these settings into the existing Alerta configuration; preserve the full existing `PLUGINS` and `ACTIONS` lists. Place this plugin last in the plugin list for the lab:

   ```python
   # Keep all existing plugin names, then append:
   PLUGINS = ['remote_ip', 'reject', 'heartbeat', 'blackout', 'forwarder', 'veeam_one_ack']
   # Add to existing custom actions if any:
   ACTIONS = ['veeam-ack-retry']
   VEEAM_ONE_ACK_CONFIG = '/etc/alerta/veeam-one-ack.json'
   ```

   The list above illustrates Alerta defaults plus this plugin; do not remove your Zabbix or other installed plugins. Existing `AUTH_REQUIRED=True` and `write:alerts` authorization remain necessary. Restart only the lab Alerta service and confirm the plugin loaded. Reload the browser for the custom action button.

## Bind and exercise one alarm

1. Trigger a benign, non-grouped test alarm on a known Veeam object and let the existing sender create its Alerta alert. Compare the actual object, alarm name and trigger timing in ONE; do not map on ID resemblance alone. Obtain the Alerta UUID, resource, event, environment, origin, `captureId` and `veeamAlarmCombinationId` from its details/raw JSON.

2. Discover ONE alarm IDs with the read-only CLI, running as the same account that runs Alerta so it can read the secret and use the shared lock:

   ```bash
   sudo -u alerta /opt/alerta/venv/bin/python -m alerta_veeam_one --config /etc/alerta/veeam-one-ack.json list --offset 0 --limit 25
   sudo -u alerta /opt/alerta/venv/bin/python -m alerta_veeam_one --config /etc/alerta/veeam-one-ack.json inspect --id 1253
   ```

   `list` returns only the requested page; compare `totalCount` and request further offsets if needed. `inspect` prints `binding_fields`, status, source, child count and current comment. It never acknowledges anything. Populate one binding keyed by the exact Alerta UUID using the example structure. Inspect current time/repeat count immediately before the test. Timestamp/count checks are freshness checks, not an immutable occurrence ID or atomic compare-and-set.

3. As an engineer, ACK the Alerta test alert. Its local status becomes acknowledged. The note should say `dry-run`; ONE remains unchanged. If it says `blocked`, correct the target mapping or investigate changed source state instead of weakening checks.

4. Set `dry_run: false` for this isolated test. The Alerta alert is already acknowledged from the dry run, so use the custom **`veeam-ack-retry`** action, with a meaningful message. Do not unack/reack merely to retry; standard repeated ACK is invalid in Alerta. Verify ONE now shows Acknowledged and the operator comment. Refresh Alerta's Notes tab for the result.

5. If using the Alerta REST API for the custom action, the route is **PUT**, not POST:

   ```http
   PUT /api/alert/<alert-uuid>/action
   Authorization: Bearer <authenticated-human-token>
   Content-Type: application/json

   {"action":"veeam-ack-retry","text":"Retry after confirming ONE connectivity"}
   ```

   Use the normal authenticated user session. API-key actions are intentionally excluded from outbound writes. Direct changes through `/status`, ingestion callbacks, unack, close, resolve and notes do not trigger this plugin. The custom action is shown globally by Alerta; it is a no-op unless the alert is an acknowledged Veeam alert with a human actor.

## Results and recovery

| Note result | Meaning and next step |
|---|---|
| `dry-run` | Binding/current state validated, no alarm mutation; local Alerta ACK is real |
| `confirmed` | Current ONE status, marker and matching trigger timestamp were observed; not a distributed transaction or proof against every recurrence race |
| `already-acknowledged` | Another/prior ACK is present; this attempt did not add or overwrite a comment |
| `blocked` | Unmapped, stale, grouped, mismatched or busy; inspect and correct the specific cause |
| `failed` | No ACK POST was attempted; check config, auth, network or TLS |
| `uncertain` | A POST may have reached ONE, or read-back changed/failed; inspect ONE before using the retry action |

Local Alerta ACK remains saved even when ONE is unavailable. There is no durable outbox or automatic retry. The deterministic comment marker helps recognize a previously completed write; it is not a Veeam idempotency key. The client never retries an ambiguous POST automatically. After a successful ACK, repeat count may advance legitimately; the client permits that on read-back but requires matching trigger time. If ONE changes trigger time during ACK on your build, the result is deliberately uncertain until examined.

The ONE operation changes alarm handling: acknowledgment is a real status change and can stop normal response actions. A successful call may replace the alarm's current comment; this is not an append-only comment API. Check its alarm history for prior comments.

Allow for synchronous call latency: the local ACK saves first, then the browser request waits for token, preflight, optional POST/read-back and revoke. The five-second setting is a per-network-operation timeout, not a total request deadline. A process kill after local ACK can leave no attempt/note; a kill after remote ACK can leave a completed remote write with no result note. Inspect both systems and use the explicit retry path. If writing an outcome note fails, the application logs its state; absence of a note is never proof that ONE was unchanged.

## Why this is single-node lab scope

The local file lock serializes ONE sessions across processes on **one Linux host**. It is not a cross-site lock. Do not enable this direct plugin across all four application servers against the same ONE credential. A separate API session owner with a durable shared outbox is the appropriate production evolution. The existing Postgres cluster can host a reviewed dedicated integration schema, without direct writes to Alerta's core tables. That extension is not included here.

The API provides no documented conditional ACK/version token. An alarm can change between GET and POST even with our identity/time/count checks. Human attributes and current status can also change during the request. Mapping, locking and read-back reduce mistakes; they do not create atomicity across Alerta and Veeam.

The earlier PowerShell transition feed still does not receive ONE acknowledgment changes through its documented script states. This plugin sends ACK in one direction only. Reverse ACK/unack synchronization, arbitrary comment mirroring, grouped-child mapping, service-account MFA, fleet-wide dynamic mappings and source reconciliation are outside this MVP.

## Tests and removal

See `VALIDATION.md` for actual executed checks, independent review findings and remaining live tests. Developer tests use a local HTTPS mock for ONE and the real installed Alerta 9.1 code with mocked database/auth effects; they do not contact your systems.

```bash
python3 -m venv .venv
.venv/bin/python -m pip install 'alerta-server==9.1.0' pytest
.venv/bin/python -m pip install --no-deps .
.venv/bin/python -m pytest -q
```

The HTTPS tests require the `openssl` command to generate a temporary local certificate. To remove the lab extension, remove `veeam_one_ack` from `PLUGINS`, remove its custom action/config entry, restart the lab service and revoke/retire its dedicated credential. This does not undo acknowledgments already made in ONE.

## Primary references

- [ONE alarm API and ACK payload](https://helpcenter.veeam.com/references/one/13/rest/tag/Alarms/index.html)
- [ONE REST privileges](https://helpcenter.veeam.com/references/one/13/rest/tag/SectionAbout/index.html)
- [ONE authentication, URLs and session behavior](https://helpcenter.veeam.com/references/one/13/rest/tag/SectionOverview/index.html)
- [ONE users and groups](https://helpcenter.veeam.com/docs/one/userguide/users_and_groups.html)
- [ONE acknowledgment/comment behavior](https://helpcenter.veeam.com/docs/one/userguide/acknowledge_single_alarms.html)
- [ONE alarm time/repeat fields](https://helpcenter.veeam.com/docs/one/userguide/view_alarms.html)
- [ONE notification placeholders](https://helpcenter.veeam.com/docs/one/userguide/alarm_notifications.html)
- [Alerta plugin catalog](https://docs.alerta.io/plugins.html), [contributed plugins](https://github.com/alerta/alerta-contrib), [configuration/custom actions](https://docs.alerta.io/configuration.html)
- Alerta 9.1 source: [action route](https://github.com/alerta/alerta/blob/v9.1.0/alerta/views/alerts.py), [hook processing](https://github.com/alerta/alerta/blob/v9.1.0/alerta/utils/api.py), [notes model](https://github.com/alerta/alerta/blob/v9.1.0/alerta/models/note.py), [alert model](https://github.com/alerta/alerta/blob/v9.1.0/alerta/models/alert.py)
