"""Read-only discovery commands. The CLI never acknowledges an alarm."""
import argparse
import json
import sys

from .core import Client, load_config, single_node_lock


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    inspect = sub.add_parser("inspect", help="Read one ONE alarm and show binding fields")
    inspect.add_argument("--id", required=True, type=int)
    listing = sub.add_parser("list", help="Read one explicitly paginated page of alarms")
    listing.add_argument("--offset", type=int, default=0)
    listing.add_argument("--limit", type=int, default=25)
    args = parser.parse_args()
    client = None
    try:
        config = load_config(args.config)
        with single_node_lock(config["lock_file"]):
            client = Client(config)
            try:
                client.login()
                if args.command == "inspect":
                    alarm = client.get_alarm(args.id)
                    output = {
                        "status": alarm.get("status"), "name": alarm.get("name"),
                        "alarmSource": alarm.get("alarmSource"),
                        "childAlarmsCount": alarm.get("childAlarmsCount"),
                        "comment": alarm.get("comment"),
                        "binding_fields": {
                            "triggered_alarm_id": alarm.get("triggeredAlarmId"),
                            "triggered_time": alarm.get("triggeredTime"),
                            "alarm_template_id": alarm.get("alarmTemplateId"),
                            "object_id": (alarm.get("alarmSource") or {}).get("objectId"),
                            "repeat_count": alarm.get("repeatCount")}}
                else:
                    if args.offset < 0 or not 1 <= args.limit <= 100:
                        raise ValueError("Invalid pagination")
                    page = client.request("GET", "/api/v2.3/alarms/triggeredAlarms?Offset="
                                          + str(args.offset) + "&Limit=" + str(args.limit))
                    output = {"offset": args.offset, "limit": args.limit, "totalCount": page.get("totalCount"),
                              "items": [{key: item.get(key) for key in
                                         ("triggeredAlarmId", "name", "status", "triggeredTime", "alarmSource", "childAlarmsCount")}
                                        for item in page.get("items", [])]}
                print(json.dumps(output, indent=2))
            finally:
                client.logout()
        return 0
    except Exception:
        print("Inspection failed; check ONE connectivity, credentials, certificate trust and configuration. No alarm write was attempted.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
