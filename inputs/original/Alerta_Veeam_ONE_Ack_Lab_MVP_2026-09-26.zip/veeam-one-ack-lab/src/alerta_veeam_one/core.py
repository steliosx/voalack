"""ACK exactly one operator-bound lab alarm; no automatic retries or database writes."""
from __future__ import annotations

import contextlib
import datetime as dt
import fcntl
import hashlib
import json
import os
from pathlib import Path
import ssl
import urllib.error
import urllib.parse
import urllib.request


class Blocked(Exception):
    pass


class TransportError(Exception):
    pass


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def timestamp(value):
    if not isinstance(value, str):
        raise Blocked("Missing source timestamp; review the binding.")
    try:
        result = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise Blocked("Invalid source timestamp; review the binding.") from None
    if result.tzinfo is None:
        raise Blocked("Source timestamps must have an explicit time zone.")
    return result.astimezone(dt.timezone.utc)


def integer(value, name, minimum=0):
    if type(value) is not int or not minimum <= value <= 9223372036854775807:
        raise Blocked("Invalid integer field: " + name)
    return value


def load_config(path):
    config = json.loads(Path(path).read_text(encoding="utf-8"))
    url = urllib.parse.urlsplit(config["one_url"])
    if (url.scheme != "https" or not url.hostname or url.username or url.password
            or url.path not in ("", "/") or url.query or url.fragment):
        raise Blocked("one_url must be a fixed HTTPS origin, without credentials or a path.")
    if type(config.get("dry_run", True)) is not bool:
        raise Blocked("dry_run must be a JSON boolean.")
    config.setdefault("dry_run", True)
    timeout = config.get("timeout_seconds", 5)
    if type(timeout) not in (int, float) or not 1 <= timeout <= 15:
        raise Blocked("timeout_seconds must be between 1 and 15.")
    config["timeout_seconds"] = timeout
    if not isinstance(config.get("bindings"), dict):
        raise Blocked("bindings must be an administrator-managed object.")
    return config


@contextlib.contextmanager
def single_node_lock(path):
    # Shared by all Alerta worker processes ON ONE HOST. Not a distributed lock.
    fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise Blocked("Another ONE operation is running; use Retry Veeam ACK shortly.") from None
        yield
    finally:
        os.close(fd)


class Client:
    def __init__(self, config):
        self.config = config
        self.base = config["one_url"].rstrip("/")
        self.token = None
        context = ssl.create_default_context(cafile=config.get("ca_file") or None)
        self.opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}), NoRedirect(),
            urllib.request.HTTPSHandler(context=context))

    def request(self, method, path, *, payload=None, form=None, expect_json=True):
        headers = {"Accept": "application/json"}
        if self.token:
            headers["Authorization"] = "Bearer " + self.token
        data = None
        if payload is not None:
            data = json.dumps(payload, ensure_ascii=True).encode("utf-8")
            headers["Content-Type"] = "application/json"
        elif form is not None:
            data = urllib.parse.urlencode(form).encode("utf-8")
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        request = urllib.request.Request(self.base + path, data=data, headers=headers, method=method)
        try:
            with self.opener.open(request, timeout=self.config["timeout_seconds"]) as response:
                if response.status != 200:
                    raise TransportError("ONE returned an unexpected HTTP status.")
                content = response.read(524289)
                if len(content) > 524288:
                    raise TransportError("ONE response exceeded the lab size limit.")
                if not expect_json:
                    return None
                if "application/json" not in response.headers.get("Content-Type", "").lower():
                    raise TransportError("ONE returned an unexpected content type.")
                decoded = json.loads(content)
                if not isinstance(decoded, dict):
                    raise TransportError("ONE returned an unexpected JSON shape.")
                return decoded
        except urllib.error.HTTPError as exc:
            raise TransportError("ONE HTTP " + str(exc.code) + "; check account, endpoint and source state.") from None
        except (urllib.error.URLError, TimeoutError, OSError, ValueError):
            # Never include tokens, credentials, response bodies or exception URLs in notes/logs.
            raise TransportError("ONE connection, TLS, timeout or JSON error.") from None

    def login(self):
        password = Path(self.config["password_file"]).read_text(encoding="utf-8").rstrip("\r\n")
        if not password:
            raise Blocked("The dedicated ONE account password is empty.")
        result = self.request("POST", "/api/token", form={
            "grant_type": "password", "username": self.config["username"], "password": password})
        token = result.get("access_token")
        if not isinstance(token, str) or not token or "\n" in token or "\r" in token:
            raise TransportError("ONE did not return a usable access token.")
        self.token = token

    def logout(self):
        if self.token:
            try:
                self.request("POST", "/api/revoke", form={"token": self.token}, expect_json=False)
            except TransportError:
                pass  # Token expires remotely; never obscure an established ACK result.
            finally:
                self.token = None

    def get_alarm(self, alarm_id):
        integer(alarm_id, "triggered_alarm_id", 1)
        return self.request("GET", "/api/v2.3/alarms/triggeredAlarms/" + str(alarm_id))

    def acknowledge(self, alarm_id, comment):
        return self.request("POST", "/api/v2.3/alarms/triggeredAlarms/resolve", payload={
            "triggeredAlarmIds": [alarm_id], "comment": comment, "resolveType": "Acknowledge"},
            expect_json=False)


def binding_for(config, alert):
    binding = config["bindings"].get(str(alert.get("id")))
    if not isinstance(binding, dict):
        raise Blocked("No approved lab binding for this Alerta ID; no ONE alarm was changed.")
    for field in ("resource", "event", "environment", "origin"):
        if not isinstance(binding.get(field), str) or not binding[field] or alert.get(field) != binding[field]:
            raise Blocked("Alerta identity differs from the approved binding: " + field)
    if alert["event"] != "VeeamOneAlarm" or not alert["resource"].startswith("veeamone:"):
        raise Blocked("The approved binding is not a Veeam ONE source alarm.")
    attrs = alert.get("attributes") or {}
    for expected, actual in (("combination_id", "veeamAlarmCombinationId"), ("capture_id", "captureId")):
        if not isinstance(binding.get(expected), str) or not binding[expected] or attrs.get(actual) != binding[expected]:
            raise Blocked("The source capture changed; review and refresh its lab binding.")
    if alert.get("value") not in ("Error", "Warning"):
        raise Blocked("Only active Error/Warning observations may be acknowledged in ONE.")
    if alert.get("severity") != {"Error": "major", "Warning": "warning"}[alert["value"]]:
        raise Blocked("Alerta severity and source state disagree.")
    for key, minimum in (("triggered_alarm_id", 1), ("alarm_template_id", 0), ("object_id", 0), ("repeat_count", 0)):
        integer(binding.get(key), key, minimum)
    timestamp(binding.get("triggered_time"))
    return binding


def check_remote_identity(alarm, binding):
    if (alarm.get("triggeredAlarmId") != binding["triggered_alarm_id"]
            or alarm.get("alarmTemplateId") != binding["alarm_template_id"]
            or (alarm.get("alarmSource") or {}).get("objectId") != binding["object_id"]):
        raise Blocked("ONE identity differs from the approved binding.")
    if type(alarm.get("childAlarmsCount")) is not int or alarm["childAlarmsCount"] != 0:
        raise Blocked("Grouped or child alarms are outside this lab MVP; no group ACK is sent.")


def bounded_comment(text, limit=1024):
    # Conservative .NET UTF-16 length bound, including non-BMP operator text.
    result, size = [], 0
    for char in text:
        if ord(char) < 32 or ord(char) == 127:
            char = " "
        units = 2 if ord(char) > 0xFFFF else 1
        if size + units > limit:
            break
        result.append(char)
        size += units
    return "".join(result)


def run_ack(alert_snapshot, operator, text, config_path):
    """Return a safe note summary. Only approved config supplies URL, credential and target."""
    operation_id = ""
    attempted = False
    try:
        if not isinstance(operator, str) or not operator.strip():
            raise Blocked("An authenticated human operator is required.")
        config = load_config(config_path)
        binding = binding_for(config, alert_snapshot)
        identity = json.dumps([str(alert_snapshot["id"]), binding], sort_keys=True).encode()
        operation_id = hashlib.sha256(identity).hexdigest()[:24]
        marker = "[AlertaAck:" + operation_id + "]"
        comment = bounded_comment(marker + " Alerta=" + str(alert_snapshot["id"])
                                  + " operator=" + operator[:160] + "; " + (text or "Acknowledged in Alerta"))
        with single_node_lock(config["lock_file"]):
            client = Client(config)
            try:
                client.login()
                alarm = client.get_alarm(binding["triggered_alarm_id"])
                check_remote_identity(alarm, binding)
                if timestamp(alarm.get("triggeredTime")) != timestamp(binding["triggered_time"]):
                    raise Blocked("ONE trigger time changed; inspect current state before refreshing the binding.")
                if alarm.get("status") == "Acknowledged" and marker in (alarm.get("comment") or ""):
                    return {"state": "confirmed", "detail": "ONE is acknowledged with this operation's comment; no repeat write.", "operationId": operation_id}
                if (type(alarm.get("repeatCount")) is not int
                        or alarm["repeatCount"] != binding["repeat_count"]):
                    raise Blocked("ONE time/repeat count changed; inspect current state and refresh the binding.")
                if alarm.get("status") == "Acknowledged":
                    return {"state": "already-acknowledged", "detail": "ONE was already acknowledged; no comment was added or replaced.", "operationId": operation_id}
                if alarm.get("status") != alert_snapshot["value"]:
                    raise Blocked("ONE state differs from the captured Error/Warning; inspect current state.")
                if config["dry_run"]:
                    return {"state": "dry-run", "detail": "Binding and ONE state validated; no alarm acknowledgment or comment was written.", "operationId": operation_id}
                attempted = True
                client.acknowledge(binding["triggered_alarm_id"], comment)
                after = client.get_alarm(binding["triggered_alarm_id"])
                check_remote_identity(after, binding)
                if timestamp(after.get("triggeredTime")) != timestamp(binding["triggered_time"]):
                    return {"state": "uncertain", "detail": "ONE trigger time changed during the request. Inspect the current alarm before retry.", "operationId": operation_id}
                if after.get("status") != "Acknowledged" or marker not in (after.get("comment") or ""):
                    return {"state": "uncertain", "detail": "ACK request returned, but status/comment was not confirmed. Inspect ONE before retry.", "operationId": operation_id}
                return {"state": "confirmed", "detail": "ONE acknowledgment and correlated operator comment verified by read-back.", "operationId": operation_id}
            finally:
                client.logout()
    except Blocked as exc:
        state = "uncertain" if attempted else "blocked"
        detail = str(exc)
    except TransportError as exc:
        state = "uncertain" if attempted else "failed"
        detail = str(exc)
    except Exception:
        state = "uncertain" if attempted else "failed"
        detail = "Write-back could not complete; check protected configuration and application logs. No automatic retry."
    if attempted:
        detail += " A write may have reached ONE; inspect it before using Retry Veeam ACK."
    return {"state": state, "detail": detail, "operationId": operation_id}
