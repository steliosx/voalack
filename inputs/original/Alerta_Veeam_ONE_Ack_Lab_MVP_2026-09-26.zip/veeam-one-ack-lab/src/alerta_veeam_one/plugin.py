"""Post-commit Veeam ONE acknowledgement hook for Alerta 9.1.

This lab adapter deliberately records outcomes as notes. Alerta 9.1's ordinary
attribute update can replace an entire stale attribute dictionary, which could
overwrite a concurrently received Veeam capture.
"""

import copy
import logging

from flask import g, has_request_context

from alerta.models.note import Note
from alerta.plugins import PluginBase

from .core import run_ack


LOG = logging.getLogger("alerta.plugins.veeam_one_ack")
STATES = frozenset(
    {"dry-run", "confirmed", "already-acknowledged", "blocked", "failed", "uncertain"}
)
ACTIONS = frozenset({"ack", "veeam-ack-retry"})


def _plain(value, limit):
    """Keep integration-generated summaries compact and on one log-safe line."""
    return " ".join(str(value).split())[:limit]


class VeeamOneAckPlugin(PluginBase):
    """Attempt ONE acknowledgement after an authenticated Alerta user action."""

    def pre_receive(self, alert, **kwargs):
        return alert

    def post_receive(self, alert, **kwargs):
        return None

    def status_change(self, alert, status, text, **kwargs):
        # This hook runs before Alerta commits and can also run for ingestion.
        return None

    def post_action(self, alert, action, text, **kwargs):
        # The Alerta action route checks write:alerts before reaching this hook.
        # The standard action and explicit retry must both leave it acknowledged.
        if action not in ACTIONS or alert.status != "ack":
            return None
        if alert.event != "VeeamOneAlarm" or not str(alert.resource).startswith("veeamone:"):
            return None
        if not has_request_context():
            return None
        # API-key owners, unauthenticated requests and source-producer requests
        # are not treated as human operators. Actor attributes are never read.
        if not g.get("user_id") or not isinstance(g.get("login"), str) or not g.login.strip():
            return None

        operator = g.login
        try:
            path = self.get_config("VEEAM_ONE_ACK_CONFIG", default=None, **kwargs)
            if not isinstance(path, str) or not path.strip():
                result = {
                    "state": "blocked",
                    "detail": "Server-owned VEEAM_ONE_ACK_CONFIG is not configured.",
                }
            else:
                snapshot = {
                    key: copy.deepcopy(getattr(alert, key, None))
                    for key in (
                        "id", "resource", "event", "environment", "origin",
                        "severity", "value", "attributes",
                    )
                }
                result = run_ack(snapshot, operator, text or "", path)
                if not isinstance(result, dict) or result.get("state") not in STATES:
                    raise ValueError("Invalid writeback result")
        except Exception as exc:
            # The local ACK has already committed. A remote/configuration failure
            # must not manufacture an HTTP failure implying the local ACK failed.
            # Never log exception text, request payloads, passwords or tokens.
            LOG.error("Veeam ONE writeback failed (%s); local ACK retained", type(exc).__name__)
            result = {
                "state": "failed",
                "detail": "Writeback failed; local Alerta acknowledgement remains. Check integration logs/configuration.",
            }

        state = result["state"]
        detail = _plain(result.get("detail", "No further detail supplied."), 800)
        note = "[Veeam ONE writeback] {0}: {1}".format(state, detail)
        operation = result.get("operationId")
        if operation:
            note += " Operation: {0}.".format(_plain(operation, 128))
        note += " Local Alerta acknowledgement is retained."
        try:
            # Write only the notes table under g.login. Alert.add_note() also
            # prepends status history using this stale alert snapshot; a newer
            # incoming Error/open could then be masked by our old ACK history.
            # Note.from_alert() does not update history or source attributes.
            Note.from_alert(alert, note)
        except Exception as exc:
            LOG.error(
                "Veeam ONE writeback outcome %s could not be recorded as a note (%s)",
                state, type(exc).__name__,
            )
        return None
