"""Lab integration; install into an existing Alerta 9.1 Python environment."""

__version__ = "0.1.0"
