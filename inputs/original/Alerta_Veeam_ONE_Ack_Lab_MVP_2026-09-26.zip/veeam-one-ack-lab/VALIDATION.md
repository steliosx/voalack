# Lab validation and independent review

26 September 2026 · Alerta Veeam ONE ACK Lab MVP 0.1.0

## Executed checks

The packaged wheel was built, installed into a separate Python environment, and loaded through its real `alerta.plugins` entry point. Tests imported the installed wheel, not an editable source checkout.

**Result: 32 tests passed, plus 21 passing subtests.** One upstream Alerta warning concerned its use of `datetime.utcnow()` on Python 3.12; no test failed. The bundled `test-results.xml` records the combined run.

Test environment: Python 3.12.14, `alerta-server==9.1.0`, `pytest==9.1.1`. Package runtime minimum is Python 3.11. The client uses Python's standard library; the plugin uses the existing Alerta/Flask environment.

| Area | Evidence |
|---|---|
| ONE REST contract | Local HTTPS server with trusted temporary certificate; exact token form, bearer requests, API 2.3 paths, one-ID ACK body, empty HTTP 200 response and read-back |
| Dry run | Token/read/revoke allowed; no alarm acknowledgment POST |
| Target control | Unknown/mutated binding, changed source capture, changed status/time/count and grouped alarms rejected |
| Attribution | Authenticated operator placed in bounded comment; client-supplied actor attributes ignored |
| Network uncertainty | POST timeout/500 and inconsistent read-back produce uncertain outcome, with no automatic repeat POST |
| TLS and locking | Untrusted certificate fails before credentials reach HTTP handler; per-host lock contention blocks another attempt |
| Retry behavior | Existing correlated ACK does not produce another POST; changed trigger time cannot be hidden by an old marker |
| Alerta authorization | Actual installed action route and permission decorator, with token decoding/database effects mocked: read-only denied before hooks, writer accepted, hook runs after local update |
| Outcome persistence | Real Alerta note model with mocked database boundary; outcome does not overwrite source attributes or append stale ACK history after a concurrent incoming Error |
| Packaging | Wheel entry point loads `VeeamOneAckPlugin`; source/config/manifest/ZIP integrity verified |

For the two trigger-time regressions, removing the fixes in an isolated copy caused both tests to fail with incorrect `confirmed` results. Shared source was unchanged by that check.

## Astra Ultra independent review

GPT-6 Astra at Ultra reasoning effort independently reviewed code, source contracts and runbook, then re-reviewed corrections and ran three focused correction regressions. All three passed.

| Severity | Finding | Correction |
|---|---|---|
| High | Alerta's ordinary `Alert.add_note()` also writes status history from its potentially stale alert object. A later source Error could be followed by that stale ACK row. | Outcome uses `Note.from_alert()` directly. Notes are visible without a status-history write or full-attribute replacement. |
| Medium | A matching comment marker bypassed trigger-time checks; post-write verification did not check that time. | Trigger time is checked before marker recognition and on read-back. A changed post-write time produces `uncertain`. |
| Medium | Python 3.10's ISO parser rejects some valid Veeam fractional-second timestamps. | Runtime floor and runbook corrected to Python 3.11+. |

The reviewer found no further high/medium implementation defect within the stated single-node lab scope. This is not a production assurance statement.

## Not executed against your infrastructure

No production service was changed and no real Veeam alarm was acknowledged. These tests did not use a real Veeam ONE server, a real PostgreSQL/Patroni cluster, deployed Duo/OIDC, a browser session, or your service account. Mocked authorization/database effects do not prove live identity-provider or database configuration.

Before enabling live writes in the lab, verify:

1. Plugin loads in the actual Alerta virtual environment; CA trust and the ONE account's permissions work.
2. A read-only human cannot invoke the action; an engineer can; a producer API key causes no outbound ACK.
3. Dry-run creates an Alerta outcome note and leaves ONE unchanged.
4. One non-grouped mapped alarm receives ACK plus the expected operator comment; existing comment/history behavior matches your operating needs.
5. An outage leaves the local ACK saved with a failure/uncertainty note; explicit retry works after inspecting ONE.
6. Source updates during the network call preserve their current Alerta state. Changed/retriggered targets are blocked or reported uncertain.
7. Native ONE `triggeredTime` remains stable across ACK on your build; if it changes, treat the result as uncertain and adjust only with documented evidence.
8. A worker/process interruption and a failed outcome-note write are detectable; absence of a note does not imply absence of a remote ACK.

The remaining GET-to-POST race, non-atomic cross-system operation, synchronous latency and crash gaps require a more durable design before expanding to the four-node/two-site production application tier. See the README for the proposed outbox/worker evolution.
