"""Adapter contract tests using Flask context and an in-memory alert double.

These test the plugin boundary, not Alerta's database, authentication middleware,
or a live Veeam ONE server. Alerta 9.1.0 and Flask must be installed in the test
environment; the real PluginBase is used.
"""

import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch

from flask import Flask, g

from alerta_veeam_one.plugin import VeeamOneAckPlugin


class FakeAlert:
    def __init__(self):
        self.id = "6f562a40-9e65-4214-9b69-7283de2c11c0"
        self.resource = "veeamone:lab:alarm:0123"
        self.event = "VeeamOneAlarm"
        self.environment = "Development"
        self.origin = "VeeamONE/lab"
        self.severity = "major"
        self.value = "Error"
        self.status = "ack"
        self.attributes = {"captureId": "capture-one", "operator": "forged-user"}
        self.customer = None
        self.add_note = Mock()
        self.update_attributes = Mock(side_effect=AssertionError("Do not replace source attributes"))


class PluginTests(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.context = self.app.test_request_context("/alert/test/action", method="PUT")
        self.context.push()
        g.user_id = "authenticated-user-id"
        g.login = "engineer@example.test"
        self.plugin = VeeamOneAckPlugin()
        self.alert = FakeAlert()
        self.config = {"VEEAM_ONE_ACK_CONFIG": "/etc/veeam-one-ack/lab.json"}
        self.runner_patcher = patch("alerta_veeam_one.plugin.run_ack")
        self.runner = self.runner_patcher.start()
        self.note_patcher = patch("alerta_veeam_one.plugin.Note.from_alert")
        self.note_writer = self.note_patcher.start()
        self.runner.return_value = {
            "state": "confirmed", "detail": "ONE acknowledgement verified.", "operationId": "op-123"
        }

    def tearDown(self):
        self.runner_patcher.stop()
        self.note_patcher.stop()
        self.alert.add_note.assert_not_called()
        self.alert.update_attributes.assert_not_called()
        self.context.pop()

    def invoke(self, action="ack", text="Investigating backup failure"):
        return self.plugin.post_action(self.alert, action, text, config=self.config)

    def test_ack_uses_authenticated_actor_and_source_snapshot(self):
        self.assertIsNone(self.invoke())
        snapshot, actor, text, path = self.runner.call_args.args
        self.assertEqual(actor, "engineer@example.test")
        self.assertNotEqual(actor, self.alert.attributes["operator"])
        self.assertEqual(snapshot["id"], self.alert.id)
        self.assertEqual(snapshot["attributes"]["captureId"], "capture-one")
        self.assertEqual(path, self.config["VEEAM_ONE_ACK_CONFIG"])
        self.assertEqual(text, "Investigating backup failure")
        self.assertEqual(set(snapshot), {
            "id", "resource", "event", "environment", "origin", "severity", "value", "attributes"
        })
        self.note_writer.assert_called_once()
        note = self.note_writer.call_args.args[1]
        self.assertIn("confirmed", note)
        self.assertIn("op-123", note)
        self.assertNotIn(text, note)
        self.alert.update_attributes.assert_not_called()

    def test_snapshot_is_deep_copy(self):
        def mutate(snapshot, *args):
            snapshot["attributes"]["captureId"] = "changed"
            return {"state": "dry-run", "detail": "No source write."}
        self.runner.side_effect = mutate
        self.invoke()
        self.assertEqual(self.alert.attributes["captureId"], "capture-one")

    def test_retry_custom_action_runs_without_local_unack(self):
        self.invoke("veeam-ack-retry")
        self.runner.assert_called_once()
        self.assertEqual(self.alert.status, "ack")

    def test_non_ack_actions_and_non_ack_state_do_nothing(self):
        for action in ("close", "open", "unack", "shelve", "note", "anything"):
            with self.subTest(action=action):
                self.invoke(action)
        self.alert.status = "open"
        self.invoke("veeam-ack-retry")
        self.runner.assert_not_called()
        self.note_writer.assert_not_called()

    def test_ingestion_and_precommit_status_hook_never_write_back(self):
        self.assertIs(self.plugin.pre_receive(self.alert), self.alert)
        self.plugin.post_receive(self.alert)
        self.plugin.status_change(self.alert, "ack", "source update", config=self.config)
        self.runner.assert_not_called()

    def test_non_veeam_alerts_do_nothing(self):
        self.alert.event = "OtherEvent"
        self.invoke()
        self.alert.event = "VeeamOneAlarm"
        self.alert.resource = "zabbix:host"
        self.invoke()
        self.runner.assert_not_called()

    def test_api_key_identity_and_missing_login_do_nothing(self):
        g.user_id = None
        g.login = "api-key-owner@example.test"
        self.invoke()
        g.user_id = "real-user"
        for login in (None, "", "   ", 42):
            g.login = login
            self.invoke()
        self.runner.assert_not_called()
        self.note_writer.assert_not_called()

    def test_missing_config_is_visible_blocked_result(self):
        self.config = {}
        with patch.dict("os.environ", {}, clear=True):
            self.invoke()
        self.runner.assert_not_called()
        self.assertIn("blocked", self.note_writer.call_args.args[1])

    def test_remote_exception_is_sanitized_and_does_not_raise(self):
        self.runner.side_effect = RuntimeError("password=must-not-appear")
        with self.assertLogs("alerta.plugins.veeam_one_ack", level="ERROR") as logs:
            self.assertIsNone(self.invoke())
        note = self.note_writer.call_args.args[1]
        self.assertIn("failed", note)
        self.assertNotIn("must-not-appear", note + " ".join(logs.output))
        self.assertEqual(self.alert.status, "ack")
        self.alert.update_attributes.assert_not_called()

    def test_invalid_core_result_is_recorded_as_failure(self):
        self.runner.return_value = {"state": "success-but-undefined"}
        with self.assertLogs("alerta.plugins.veeam_one_ack", level="ERROR"):
            self.invoke()
        self.assertIn("failed", self.note_writer.call_args.args[1])

    def test_note_storage_failure_does_not_raise_or_expose_exception_text(self):
        self.note_writer.side_effect = RuntimeError("postgres://private-secret")
        with self.assertLogs("alerta.plugins.veeam_one_ack", level="ERROR") as logs:
            self.assertIsNone(self.invoke())
        self.assertIn("confirmed", " ".join(logs.output))
        self.assertNotIn("private-secret", " ".join(logs.output))

    def test_outcome_note_has_single_line_bounded_detail(self):
        self.runner.return_value = {
            "state": "blocked", "detail": "line1\nline2\t" + "x" * 2000, "operationId": "a" * 300
        }
        self.invoke()
        note = self.note_writer.call_args.args[1]
        self.assertNotIn("\n", note)
        self.assertNotIn("\t", note)
        self.assertLess(len(note), 1100)

    def test_real_note_model_cannot_prepend_stale_ack_after_incoming_error(self):
        # Exercise the installed real Note.from_alert/create/from_db methods.
        # Only the database boundary is mocked. The post-action alert object is
        # deliberately stale after a newer Error/open arrives during HTTP I/O.
        self.note_patcher.stop()
        current = {"status": "ack", "history": [{"status": "ack"}]}

        def incoming_error_during_outbound(*args):
            current["status"] = "open"
            current["history"].insert(0, {"status": "open", "severity": "major"})
            return {"state": "confirmed", "detail": "Earlier ONE acknowledgement verified."}

        self.runner.side_effect = incoming_error_during_outbound
        with patch("alerta.models.note.db") as database:
            def store_note(note):
                return {
                    "id": note.id, "text": note.text, "user": note.user,
                    "type": note.note_type, "alert": note.alert,
                    "attributes": note.attributes, "customer": note.customer,
                }
            database.create_note.side_effect = store_note
            self.invoke()
            database.create_note.assert_called_once()
            database.add_history.assert_not_called()
            note = database.create_note.call_args.args[0]
            self.assertEqual(note.alert, self.alert.id)
            self.assertEqual(note.user, "engineer@example.test")
            self.assertIn("confirmed", note.text)
        self.assertEqual(self.alert.status, "ack")  # stale callback snapshot
        self.assertEqual(current["status"], "open")
        self.assertEqual(current["history"][0]["status"], "open")
        self.assertEqual(len(current["history"]), 2)
        self.alert.add_note.assert_not_called()
        self.alert.update_attributes.assert_not_called()


class ActualActionRouteTests(unittest.TestCase):
    """Exercise the installed Alerta action route and permission decorator.

    Authentication decoding and all database effects are replaced with doubles.
    This checks real route/hook ordering and scope gates, not JWT cryptography,
    the database commit implementation, or a live browser session.
    """

    def setUp(self):
        from alerta.exceptions import ApiError
        from alerta.views.alerts import action_alert

        self.app = Flask(__name__)
        self.app.config["PLUGINS_RAISE_ON_ERROR"] = True
        self.app.config["AUTH_REQUIRED"] = True
        self.app.add_url_rule("/alert/<alert_id>/action", view_func=action_alert, methods=["PUT"])
        self.app.register_error_handler(ApiError, lambda error: ({"error": error.message}, error.code))
        self.alert = FakeAlert()
        self.alert.status = "open"
        self.alert.is_suppressed = False
        self.commit_called = False

        def from_action(action, text, timeout):
            self.commit_called = True
            self.alert.status = "ack"
            return self.alert

        self.alert.from_action = Mock(side_effect=from_action)
        self.plugin = VeeamOneAckPlugin()
        self.token = SimpleNamespace(
            oid="user-id", subject="user-id", preferred_username="engineer@example.test",
            customers=[], scopes=["write:alerts"],
        )
        self.patches = [
            patch("alerta.auth.decorators.Jwt.parse", return_value=self.token),
            patch("alerta.views.alerts.Alert.find_by_id", return_value=self.alert),
            patch("alerta.utils.api.plugins.routing", return_value=(
                [self.plugin], {"VEEAM_ONE_ACK_CONFIG": "/etc/veeam-one-ack/lab.json"}
            )),
            patch("alerta.views.alerts.status_timer.stop_timer"),
            patch("alerta.views.alerts.write_audit_trail.send"),
            patch("alerta_veeam_one.plugin.run_ack"),
            patch("alerta_veeam_one.plugin.Note.from_alert"),
        ]
        self.mocks = [item.start() for item in self.patches]
        self.runner = self.mocks[-2]
        self.note_writer = self.mocks[-1]

        def confirm_after_commit(*args):
            self.assertTrue(self.commit_called)
            self.assertEqual(self.alert.status, "ack")
            return {"state": "confirmed", "detail": "ONE acknowledgement verified."}

        self.runner.side_effect = confirm_after_commit
        self.client = self.app.test_client()

    def tearDown(self):
        for item in reversed(self.patches):
            item.stop()
        self.alert.add_note.assert_not_called()
        self.alert.update_attributes.assert_not_called()

    def send(self):
        return self.client.put(
            "/alert/{0}/action".format(self.alert.id),
            headers={"Authorization": "Bearer fake-token"},
            json={"action": "ack", "text": "Investigating"},
        )

    def test_readonly_user_gets_403_before_lookup_commit_or_hook(self):
        self.token.scopes = ["read:alerts"]
        response = self.send()
        self.assertEqual(response.status_code, 403)
        self.mocks[1].assert_not_called()
        self.assertFalse(self.commit_called)
        self.runner.assert_not_called()

    def test_authorized_ack_calls_hook_after_local_update(self):
        response = self.send()
        self.assertEqual(response.status_code, 200)
        self.runner.assert_called_once()
        self.assertEqual(self.runner.call_args.args[1], "engineer@example.test")
        self.note_writer.assert_called_once()
        self.alert.update_attributes.assert_not_called()

    def test_remote_failure_keeps_http_success_and_ack(self):
        self.runner.side_effect = RuntimeError("Veeam unavailable")
        with self.assertLogs("alerta.plugins.veeam_one_ack", level="ERROR"):
            response = self.send()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.alert.status, "ack")
        self.assertIn("failed", self.note_writer.call_args.args[1])


if __name__ == "__main__":
    unittest.main()
