"""Lab write-back tests against a real, local HTTPS mock of ONE API 2.3.

Requires the openssl CLI only to generate an ephemeral test certificate.
No Veeam/Alerta server or production credentials are used.
"""

import copy
import fcntl
import json
import shutil
import ssl
import subprocess
import tempfile
import threading
import time
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs

from alerta_veeam_one.core import run_ack


# Field names/status values checked against Veeam's official API 2.3 OpenAPI.
REMOTE_ALARM = {
    "triggeredAlarmId": 1253,
    "name": "Latest snapshot age",
    "alarmTemplateId": 112,
    "predefinedAlarmId": 112,
    "triggeredTime": "2026-09-26T21:00:00.000Z",
    "status": "Warning",
    "description": "Lab VM snapshot age exceeds the threshold.",
    "comment": "",
    "repeatCount": 3,
    "alarmSource": {
        "objectId": 1014,
        "objectName": "lab-vm-01",
        "objectType": "VSphereVm",
    },
    "childAlarmsCount": 0,
    "remediation": {"items": []},
}


class MockState:
    def __init__(self):
        self.alarm = copy.deepcopy(REMOTE_ALARM)
        self.requests = []
        self.resolve_behavior = "success"
        self.get_behavior = "success"

    @property
    def writes(self):
        return [r for r in self.requests if r[0] == "POST" and r[1].endswith("/resolve")]


class VeeamHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_):
        pass

    def reply(self, code, payload=None):
        data = b"" if payload is None else json.dumps(payload).encode()
        try:
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            if data:
                self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError, ssl.SSLError):
            pass
        self.close_connection = True

    def do_GET(self):
        state = self.server.state
        state.requests.append(("GET", self.path, dict(self.headers), None))
        if self.headers.get("Authorization") != "Bearer test-access-token":
            return self.reply(401, {"detail": "missing test bearer"})
        if self.path != "/api/v2.3/alarms/triggeredAlarms/1253":
            return self.reply(404, {"detail": "unknown test alarm"})
        if state.get_behavior == "500":
            return self.reply(500, {"detail": "lab GET failed"})
        return self.reply(200, state.alarm)

    def do_POST(self):
        state = self.server.state
        data = self.rfile.read(int(self.headers.get("Content-Length", "0")))
        if self.headers.get_content_type() == "application/x-www-form-urlencoded":
            payload = parse_qs(data.decode())
        else:
            try:
                payload = json.loads(data)
            except (ValueError, UnicodeError):
                payload = None
        state.requests.append(("POST", self.path, dict(self.headers), payload))
        if self.path == "/api/token":
            if payload != {
                "grant_type": ["password"],
                "username": ["LAB\\svc_alerta_ack"],
                "password": ["fake-lab-password"],
            }:
                return self.reply(400, {"detail": "bad test login contract"})
            return self.reply(200, {
                "access_token": "test-access-token",
                "refresh_token": "test-refresh-token",
                "token_type": "Bearer",
                "expires_in": 899,
                "user": "LAB\\svc_alerta_ack",
                "user_role": "Admin",
            })
        if self.headers.get("Authorization") != "Bearer test-access-token":
            return self.reply(401, {"detail": "missing test bearer"})
        if self.path == "/api/revoke":
            return self.reply(200)
        if self.path != "/api/v2.3/alarms/triggeredAlarms/resolve":
            return self.reply(404, {"detail": "unknown test endpoint"})
        if state.resolve_behavior == "500":
            return self.reply(500, {"detail": "ambiguous lab server error"})
        if state.resolve_behavior == "timeout":
            time.sleep(2)
            return self.reply(200)
        if state.resolve_behavior == "no-change":
            return self.reply(200)
        state.alarm["status"] = "Acknowledged"
        state.alarm["comment"] = payload["comment"]
        # Veeam UI documentation counts status changes, too. Do not assume a
        # repeat count stays unchanged after a successful acknowledgment.
        state.alarm["repeatCount"] += 1
        if state.resolve_behavior == "success-new-trigger":
            state.alarm["triggeredTime"] = "2026-09-26T22:00:00Z"
        return self.reply(200)  # Official success contract permits an empty body.


class HTTPSMock:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.cert = self.directory / "localhost.pem"
        self.key = self.directory / "localhost.key"
        subprocess.run([
            "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
            "-days", "1", "-keyout", str(self.key), "-out", str(self.cert),
            "-subj", "/CN=localhost",
            "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1",
        ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), VeeamHandler)
        self.server.daemon_threads = True
        self.server.state = MockState()
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(str(self.cert), str(self.key))
        self.server.socket = context.wrap_socket(self.server.socket, server_side=True)
        self.url = "https://localhost:%d" % self.server.server_port
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def close(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)


@unittest.skipUnless(shutil.which("openssl"), "openssl CLI required for the local HTTPS certificate")
class CoreHTTPSTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cert_directory = tempfile.TemporaryDirectory(prefix="veeam-ack-tls-")
        cls.mock = HTTPSMock(cls.cert_directory.name)

    @classmethod
    def tearDownClass(cls):
        cls.mock.close()
        cls.cert_directory.cleanup()

    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(prefix="veeam-ack-case-")
        root = Path(self.directory.name)
        self.config_path = root / "config.json"
        password_file = root / "password"
        password_file.write_text("fake-lab-password\n", encoding="utf-8")
        self.mock.server.state = MockState()
        self.state = self.mock.server.state
        self.alert = {
            "id": "6f562a40-9e65-4214-9b69-7283de2c11c0",
            "resource": "veeamone:lab:alarm:binding-fixture",
            "event": "VeeamOneAlarm",
            "environment": "Development",
            "origin": "VeeamONE/lab",
            "severity": "warning",
            "value": "Warning",
            "attributes": {
                "veeamAlarmCombinationId": "lab-notification-id",
                "captureId": "0cc99e22-00bc-4b40-a4ac-78e01b7c203f",
            },
        }
        binding = {
            "resource": self.alert["resource"],
            "event": self.alert["event"],
            "environment": self.alert["environment"],
            "origin": self.alert["origin"],
            "combination_id": self.alert["attributes"]["veeamAlarmCombinationId"],
            "capture_id": self.alert["attributes"]["captureId"],
            "triggered_alarm_id": 1253,
            "alarm_template_id": 112,
            "object_id": 1014,
            "repeat_count": 3,
            "triggered_time": REMOTE_ALARM["triggeredTime"],
        }
        self.config = {
            "one_url": self.mock.url,
            "username": "LAB\\svc_alerta_ack",
            "password_file": str(password_file),
            "ca_file": str(self.mock.cert),
            "lock_file": str(root / "worker.lock"),
            "timeout_seconds": 1,
            "bindings": {self.alert["id"]: binding},
        }
        self.operator = "engineer@example.test"

    def tearDown(self):
        self.directory.cleanup()

    def invoke(self, text="Investigating the lab snapshot"):
        self.config_path.write_text(json.dumps(self.config), encoding="utf-8")
        return run_ack(self.alert, self.operator, text, str(self.config_path))

    def live(self, **changes):
        self.config["dry_run"] = False
        self.config.update(changes)

    def test_default_dry_run_validates_without_resolve(self):
        result = self.invoke()
        self.assertEqual(result["state"], "dry-run", result)
        self.assertEqual(self.state.writes, [])
        self.assertEqual([r[1] for r in self.state.requests], [
            "/api/token", "/api/v2.3/alarms/triggeredAlarms/1253", "/api/revoke"
        ])
        self.assertEqual(self.state.requests[-1][3], {"token": ["test-access-token"]})

    def test_ack_one_id_empty_200_verified_with_operator_comment(self):
        self.live()
        result = self.invoke()
        self.assertEqual(result["state"], "confirmed", result)
        self.assertEqual(len(self.state.writes), 1)
        payload = self.state.writes[0][3]
        self.assertEqual(set(payload), {"triggeredAlarmIds", "comment", "resolveType"})
        self.assertEqual(payload["triggeredAlarmIds"], [1253])
        self.assertEqual(payload["resolveType"], "Acknowledge")
        self.assertIn(self.operator, payload["comment"])
        self.assertIn(self.alert["id"], payload["comment"])
        self.assertIn("[AlertaAck:" + result["operationId"] + "]", payload["comment"])
        self.assertIn("Investigating the lab snapshot", payload["comment"])
        self.assertEqual(self.state.alarm["repeatCount"], 4)
        self.assertEqual([r[0] for r in self.state.requests], ["POST", "GET", "POST", "GET", "POST"])

    def test_repeat_after_confirmed_ack_never_posts_again(self):
        self.live()
        first = self.invoke()
        self.assertEqual(first["state"], "confirmed", first)
        second = self.invoke("A second operator note should not overwrite the first.")
        self.assertEqual(second["state"], "confirmed", second)
        self.assertEqual(first["operationId"], second["operationId"])
        self.assertEqual(len(self.state.writes), 1)
        self.assertNotIn("second operator note", self.state.alarm["comment"])

    def test_own_marker_on_ack_with_changed_trigger_time_is_blocked(self):
        preview = self.invoke()
        self.assertEqual(preview["state"], "dry-run", preview)
        self.state.alarm["status"] = "Acknowledged"
        self.state.alarm["comment"] = "[AlertaAck:" + preview["operationId"] + "] retained comment"
        self.state.alarm["triggeredTime"] = "2026-09-26T22:00:00Z"
        self.live()
        result = self.invoke()
        self.assertEqual(result["state"], "blocked", result)
        self.assertEqual(self.state.writes, [])

    def test_changed_trigger_time_after_ack_is_uncertain_despite_own_marker(self):
        self.live()
        self.state.resolve_behavior = "success-new-trigger"
        result = self.invoke()
        self.assertEqual(self.state.alarm["status"], "Acknowledged")
        self.assertIn("[AlertaAck:" + result["operationId"] + "]", self.state.alarm["comment"])
        self.assertEqual(result["state"], "uncertain", result)
        self.assertEqual(len(self.state.writes), 1)

    def test_unbound_alert_is_blocked_without_any_remote_request(self):
        self.live()
        self.alert["id"] = "another-alert"
        result = self.invoke()
        self.assertEqual(result["state"], "blocked", result)
        self.assertEqual(self.state.requests, [])

    def test_changed_capture_or_identity_is_blocked_before_login(self):
        self.live()
        original = copy.deepcopy(self.alert)
        for field in ("resource", "event", "environment", "origin", "captureId", "veeamAlarmCombinationId"):
            with self.subTest(field=field):
                self.alert = copy.deepcopy(original)
                target = self.alert["attributes"] if field in self.alert["attributes"] else self.alert
                target[field] = "different-value"
                result = self.invoke()
                self.assertEqual(result["state"], "blocked", result)
                self.assertEqual(self.state.requests, [])

    def test_changed_remote_count_time_identity_or_status_never_resolves(self):
        self.live()
        cases = [
            ("repeatCount", 4), ("triggeredTime", "2026-09-26T22:00:00Z"),
            ("triggeredAlarmId", 1254), ("alarmTemplateId", 113),
            ("alarmSource", {"objectId": 1015}),
            ("status", "Resolved"), ("status", "Error"),
            ("childAlarmsCount", 1), ("childAlarmsCount", None),
        ]
        for field, value in cases:
            with self.subTest(field=field, value=value):
                self.state.alarm = copy.deepcopy(REMOTE_ALARM)
                self.state.alarm[field] = value
                result = self.invoke()
                self.assertEqual(result["state"], "blocked", result)
                self.assertEqual(self.state.writes, [])

    def test_other_ack_is_left_unchanged(self):
        self.live()
        self.state.alarm["status"] = "Acknowledged"
        self.state.alarm["comment"] = "Someone acknowledged in Veeam ONE."
        result = self.invoke()
        self.assertEqual(result["state"], "already-acknowledged", result)
        self.assertEqual(self.state.writes, [])
        self.assertEqual(self.state.alarm["comment"], "Someone acknowledged in Veeam ONE.")

    def test_post_500_is_uncertain_and_not_automatically_retried(self):
        self.live()
        self.state.resolve_behavior = "500"
        result = self.invoke()
        self.assertEqual(result["state"], "uncertain", result)
        self.assertEqual(len(self.state.writes), 1)
        self.assertEqual(self.state.requests[-1][1], "/api/revoke")
        self.assertNotIn("fake-lab-password", json.dumps(result))
        self.assertNotIn("test-access-token", json.dumps(result))

    def test_post_timeout_is_uncertain_and_not_automatically_retried(self):
        self.live()
        self.state.resolve_behavior = "timeout"
        result = self.invoke()
        self.assertEqual(result["state"], "uncertain", result)
        self.assertEqual(len(self.state.writes), 1)
        self.assertEqual(self.state.requests[-1][1], "/api/revoke")

    def test_empty_200_without_ack_state_is_uncertain(self):
        self.live()
        self.state.resolve_behavior = "no-change"
        result = self.invoke()
        self.assertEqual(result["state"], "uncertain", result)
        self.assertEqual(len(self.state.writes), 1)

    def test_preflight_failure_is_failed_and_never_resolves(self):
        self.live()
        self.state.get_behavior = "500"
        result = self.invoke()
        self.assertEqual(result["state"], "failed", result)
        self.assertEqual(self.state.writes, [])
        self.assertEqual(self.state.requests[-1][1], "/api/revoke")

    def test_untrusted_tls_never_sends_credentials_or_resolve(self):
        self.live()
        self.config.pop("ca_file")
        result = self.invoke()
        self.assertEqual(result["state"], "failed", result)
        self.assertEqual(self.state.requests, [])

    def test_lock_contention_blocks_before_login(self):
        self.live()
        with open(self.config["lock_file"], "w") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            result = self.invoke()
        self.assertEqual(result["state"], "blocked", result)
        self.assertEqual(self.state.requests, [])

    def test_comment_keeps_marker_and_attribution_within_utf16_limit(self):
        self.live()
        result = self.invoke("\n\t" + "\U0001f680" * 2000)
        self.assertEqual(result["state"], "confirmed", result)
        comment = self.state.writes[0][3]["comment"]
        self.assertLessEqual(len(comment.encode("utf-16-le")) // 2, 1024)
        self.assertIn(self.operator, comment)
        self.assertIn("[AlertaAck:" + result["operationId"] + "]", comment)
        self.assertNotIn("\n", comment)
        self.assertNotIn("\t", comment)


if __name__ == "__main__":
    unittest.main()
